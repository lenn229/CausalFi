# -*- coding: utf-8 -*-
import os
import sys
import json
import torch
import numpy as np
from types import SimpleNamespace

sys.path.append("./wifi")
sys.path.append("./domainbed")
# =====================================

from processor_v2 import Processor

def _make_args(
    data_dir,
    dataset,
    output_dir,
    test_envs,
    use_gpu=True,
    steps=None,
    checkpoint_freq=100,
    holdout_fraction=0.2,
    uda_holdout_fraction=0.0,
    task="domain_generalization",
    trial_seed=0,
    seed=0,
    save_model_every_checkpoint=False,
    save_freq=None
):

    return SimpleNamespace(
        data_dir=data_dir,
        dataset=dataset,
        output_dir=output_dir,
        test_envs=list(test_envs),
        hparams_json=None,
        seed=seed,
        trial_seed=trial_seed,
        checkpoint_freq=checkpoint_freq,
        save_model_every_checkpoint=save_model_every_checkpoint,
        steps=steps,  # Usually handled inside Processor via hparams/hparams2; kept as placeholder
        holdout_fraction=holdout_fraction,
        uda_holdout_fraction=uda_holdout_fraction,
        use_gpu=use_gpu,
        task=task,
        save_freq=save_freq
    )

def _make_hparams_for_cvae(
    batch_size=32,
    steps=50,  
    distance_func="kld",
    topk=1,
    class_balanced=False,
    latent_size=128,
    lr=1e-4,
    kl_weight=1,
    distribution="Gaussian_fixed_variance",
    weights=None, 
    n_nodes=8,
    weight_decay=1e-4
):
    if weights is None:

        weights = [1.0 / n_nodes] * n_nodes

    hparams = {
        # —— Common keys for training and matching ——
        "batch_size": int(batch_size),
        "batch_size_balanced": int(batch_size),
        "steps": int(steps),
        "distance_func": distance_func,
        "topk": int(topk),
        "class_balanced": bool(class_balanced),

        # —— CVAE required keys —— 
        "latent_size": int(latent_size),
        "lr": float(lr),
        "kl_weight": float(kl_weight),
        "distribution": str(distribution),
        "weights": [float(w) for w in weights],
        "weight_decay": float(weight_decay),
    }
    return hparams

def _make_hparams_for_classifier(
    batch_size=32,
    steps=300,
    pro1=0.5, al1=0.1,
    pro2=0.5, al2=0.1
):

    hparams2 = {
        "batch_size": batch_size,
        "batch_size_balanced": batch_size,
        "steps": int(steps),
        "pro1": float(pro1),
        "al1": float(al1),
        "pro2": float(pro2),
        "al2": float(al2)
    }
    return hparams2

def run_end2end(
    data_dir,
    dataset,
    output_dir,
    test_envs=(0,),
    use_gpu=True,
    matcher_checkpoint=None,  # Path to a pre-trained CVAE if available; otherwise set to None and train CVAE with steps_cvae > 0
    steps_cvae=0,             # When >0, trains the CVAE for several steps first
    steps_cls=300,            # Number of steps for classifier training
    batch_size=32,
    batch_size_1=15,
    cache_dir=None 
):
    device = 'cuda:3' if (use_gpu and torch.cuda.is_available()) else 'cpu'

    args = _make_args(
        data_dir=data_dir,
        dataset=dataset,
        output_dir=output_dir,
        test_envs=test_envs,
        use_gpu=use_gpu,
        steps=None,                 # Training steps are controlled by hparams/hparams2
        checkpoint_freq=10,
        holdout_fraction=0.2,
        uda_holdout_fraction=0.0,
        task="domain_generalization",
        trial_seed=0,
        seed=0,
        save_model_every_checkpoint=False,
        save_freq=None
    )

    hparams = _make_hparams_for_cvae(
        batch_size=batch_size,
        steps=50,
        distance_func="kld",
        topk=1,
        class_balanced=False,
        latent_size=128,
        lr=1e-3,
        kl_weight=1e-1,
        distribution="Gaussian_fixed_variance",
        weights=[0.125]*8, 
        n_nodes=8,
        weight_decay=1e-4
    )

    # —— Classifier hyperparameters
    hparams2 = _make_hparams_for_classifier(
        batch_size=batch_size_1,
        steps=int(steps_cls),
        pro1=0.5, al1=0.1, pro2=0.5, al2=0.1
    )

    # ---------- Print configuration before proceeding ----------
    print("\n===== ARGS (Processor) =====")
    print(json.dumps(vars(args), indent=2, ensure_ascii=False))
    print("\n===== HPARAMS (CVAE) =====")
    print(json.dumps(hparams, indent=2, ensure_ascii=False))
    print("\n===== HPARAMS2 (Classifier) =====")
    print(json.dumps(hparams2, indent=2, ensure_ascii=False))
    print("\n====== Start Execution ======\n")


    # ---------- Instantiate and load dataset ----------
    print("[1/4] Loading dataset & splits ...")
    proc = Processor(args, hparams, hparams2, device=device)
    proc.load_data()
    print("  in_splits :", [len(s[0]) for s in proc.in_splits])
    print("  out_splits:", [len(s[0]) for s in proc.out_splits])
    print("  uda_splits:", [len(s[0]) for s in proc.uda_splits])

    # ---------- A) If no pre-trained CVAE exists, train briefly----------
    if matcher_checkpoint is None and steps_cvae > 0:
        print("[2/4] Training CVAE briefly (steps = %d) ..." % steps_cvae)
        os.makedirs(output_dir, exist_ok=True)
        proc.hparams["steps"] = int(steps_cvae)
        proc.train_cvae() 
        matcher_checkpoint = os.path.join(output_dir, "model.pkl")

    if matcher_checkpoint is None:
        raise RuntimeError(
            "Please provide matcher_checkpoint."
        )

    # ---------- Calculate matching ----------
    if cache_dir is not None:
        print("[3/4] Preparing CVAE matches & caching ...")
        os.makedirs(cache_dir, exist_ok=True)
        cache_path = proc.prepare_cvae(matcher_checkpoint, cache_output_dir=cache_dir)
        print("  cache saved ->", cache_path)
        cache = torch.load(cache_path, map_location='cpu')
        all_vars, final_b = cache["all_vars"], cache["final_b"]
    else:
        print("[3/4] Computing CVAE matches on the fly ...")
        matcher = proc.load_cvae_from_checkpoint(matcher_checkpoint, device=device)
        all_vars, final_b = proc.compute_causal_scores(matcher, batch_size=hparams["batch_size"])

    # ---------- C) Train classifier ----------
    print("[4/4] Training classifier (steps = %d) ..." % steps_cls)
    proc.train_classifier(all_vars, final_b)
    print("Done ✓")
    return True


if __name__ == "__main__":
    DATA_DIR   = "/home/data_save_1/"
    DATASET    = "WiFi_simple_try" #just some random data for simple try
    OUT_DIR    = "/home/newdisk/cyn/Project/New_balanced_WiFi/Experiment_Optuna_Widar/domainbed/revision/github/CausalFi_release/tmp/wifi_demo_out"
    TEST_ENVS  = (0,)
    USE_GPU    = True
    MATCHER_CKPT = None          # If a pre-trained CVAE exists, provide its path; otherwise set to None and train with STEPS_CVAE > 0
    STEPS_CVAE = 100             # Train CVAE for a small number of steps first
    STEPS_CLS  = 50              # Train classifier for a small number of steps
    BATCH_SIZE = 32
    CACHE_DIR  = None            # Optionally set a directory for prepare_cvae before training
    # ============================================

    ok = run_end2end(
        data_dir=DATA_DIR,
        dataset=DATASET,
        output_dir=OUT_DIR,
        test_envs=TEST_ENVS,
        use_gpu=USE_GPU,
        matcher_checkpoint=MATCHER_CKPT,
        steps_cvae=STEPS_CVAE,
        steps_cls=STEPS_CLS,
        batch_size=BATCH_SIZE,
        cache_dir=CACHE_DIR
    )
    print("RESULT:", ok)
