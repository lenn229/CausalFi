import math
import pdb
import numpy as np
import torch
import torch.nn as nn
from torch.autograd import Variable
from torch.nn.utils import weight_norm
import random
from more_itertools import chunked

def import_class(name):
    components = name.split('.')
    mod = __import__(components[0])
    for comp in components[1:]:
        mod = getattr(mod, comp)
    return mod


def conv_branch_init(conv, branches):
    weight = conv.weight
    n = weight.size(0)
    k1 = weight.size(1)
    k2 = weight.size(2)
    nn.init.normal_(weight, 0, math.sqrt(2. / (n * k1 * k2 * branches)))
    nn.init.constant_(conv.bias, 0)


def conv_init(conv):
    if conv.weight is not None:
        nn.init.kaiming_normal_(conv.weight, mode='fan_out')
    if conv.bias is not None:
        nn.init.constant_(conv.bias, 0)


def bn_init(bn, scale):
    nn.init.constant_(bn.weight, scale)
    nn.init.constant_(bn.bias, 0)


def weights_init(m):
    classname = m.__class__.__name__
    if classname.find('Conv') != -1:
        if hasattr(m, 'weight'):
            nn.init.kaiming_normal_(m.weight, mode='fan_out')
        if hasattr(m, 'bias') and m.bias is not None and isinstance(m.bias, torch.Tensor):
            nn.init.constant_(m.bias, 0)
    elif classname.find('BatchNorm') != -1:
        if hasattr(m, 'weight') and m.weight is not None:
            m.weight.data.normal_(1.0, 0.02)
        if hasattr(m, 'bias') and m.bias is not None:
            m.bias.data.fill_(0)


class Chomp1d(nn.Module):
    def __init__(self, chomp_size):
        super(Chomp1d, self).__init__()
        self.chomp_size = chomp_size

    def forward(self, x):
        return x[:, :, :-self.chomp_size].contiguous()


class TemporalBlock(nn.Module):
    def __init__(self, n_inputs, n_outputs, kernel_size, stride, dilation, padding, dropout=0.2):
        super(TemporalBlock, self).__init__()
        self.conv1 = weight_norm(nn.Conv1d(n_inputs, n_outputs, kernel_size,
                                           stride=stride, padding=padding, dilation=dilation))
        self.chomp1 = Chomp1d(padding)

        self.net = nn.Sequential(self.conv1, self.chomp1)
        self.init_weights()

    def init_weights(self):
        self.conv1.weight.data.normal_(0, 0.01)

    def forward(self, x):
        out = self.net(x)
        return out


class TemporalConvNet(nn.Module):
    def __init__(self, num_inputs, num_channels, kernel_size=2, dropout=0):
        super(TemporalConvNet, self).__init__()
        layers = []
        num_levels = len(num_channels)
        for i in range(num_levels):
            dilation_size = 2 ** i
            in_channels = num_inputs if i == 0 else num_channels[i-1]
            out_channels = num_channels[i]
            layers += [TemporalBlock(in_channels, out_channels, kernel_size, stride=1, dilation=dilation_size,
                                     padding=(kernel_size-1) * dilation_size, dropout=dropout)]

        self.network = nn.Sequential(*layers)

    def forward(self, x):
        return self.network(x)
    

class TemporalConv(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1, dilation=1):
        super(TemporalConv, self).__init__()
        pad = (kernel_size + (kernel_size-1) * (dilation-1) - 1) // 2
        self.conv = nn.Conv2d(
            in_channels,
            out_channels,
            kernel_size=(kernel_size, 1),
            padding=(pad, 0),
            stride=(stride, 1),
            dilation=(dilation, 1))

        self.bn = nn.BatchNorm2d(out_channels)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        return x


class MultiScale_TemporalConv_1(nn.Module):
    def __init__(self,
                 in_channels,
                 out_channels,
                 kernel_size=3,
                 stride=1,
                 dilations=[1,2,3,4],
                 residual=True,
                 residual_kernel_size=1):

        super().__init__()
        assert out_channels % (len(dilations) + 2) == 0, '# out channels should be multiples of # branches'

        # Multiple branches of temporal convolution
        self.num_branches = len(dilations) + 2
        branch_channels = out_channels // self.num_branches
        if type(kernel_size) == list:
            assert len(kernel_size) == len(dilations)
        else:
            kernel_size = [kernel_size]*len(dilations)
        # Temporal Convolution branches
        self.branches = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(
                    in_channels,
                    branch_channels,
                    kernel_size=1,
                    padding=0),
                nn.BatchNorm2d(branch_channels),
                nn.ReLU(inplace=True),
                TemporalConv(
                    branch_channels,
                    branch_channels,
                    kernel_size=ks,
                    stride=stride,
                    dilation=dilation),
            )
            for ks, dilation in zip(kernel_size, dilations)
        ])

        # Additional Max & 1x1 branch
        self.branches.append(nn.Sequential(
            nn.Conv2d(in_channels, branch_channels, kernel_size=1, padding=0),
            nn.BatchNorm2d(branch_channels),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=(3,1), stride=(stride,1), padding=(1,0)),
            nn.BatchNorm2d(branch_channels) 
        ))

        self.branches.append(nn.Sequential(
            nn.Conv2d(in_channels, branch_channels, kernel_size=1, padding=0, stride=(stride,1)),
            nn.BatchNorm2d(branch_channels)
        ))

        if not residual:
            self.residual = lambda x: 0
        elif (in_channels == out_channels) and (stride == 1):
            self.residual = lambda x: x
        else:
            self.residual = TemporalConv(in_channels, out_channels, kernel_size=residual_kernel_size, stride=stride)

        # initialize
        self.apply(weights_init)

    def forward(self, x):
        # Input dim: (N,C,T,V)
        res = self.residual(x)
        branch_outs = []
        for tempconv in self.branches:
            out = tempconv(x)
            branch_outs.append(out)
        out = torch.cat(branch_outs, dim=1)
        #out += res
        return out
    

class MultiScale_TemporalConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(MultiScale_TemporalConv, self).__init__()
        self.conv = nn.Conv2d(
            in_channels,
            out_channels,
            kernel_size=(1, 1))

        self.bn = nn.BatchNorm2d(out_channels)

    def forward(self, x):
        x = self.conv(x)
        #x = self.bn(x)
        return x

class CTRGC_1(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(CTRGC_1, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.conv1 = nn.Conv2d(self.in_channels, self.out_channels, kernel_size=1)
        self.conv2 = nn.Conv2d(self.in_channels, self.out_channels, kernel_size=[2,1])
        self.tcnA1 = MultiScale_TemporalConv(144, 16)
        self.tanh = nn.Tanh()
        self.relu = nn.ReLU(inplace=True)
        self.bn = nn.BatchNorm2d(out_channels)
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                conv_init(m)
            elif isinstance(m, nn.BatchNorm2d):
                bn_init(m, 1)

    def forward(self, x, A=None, alpha=0.5):
        x1, x2, x3 = x.mean(-2), x.mean(-2), self.conv1(x)
        y1 = x1.unsqueeze(2)-x2.unsqueeze(3)*0
        y2 = x1.unsqueeze(3)-x2.unsqueeze(2)*0
        x1 = torch.cat([y1.unsqueeze(2),y2.unsqueeze(2)],dim=2).view(y1.size(0),self.in_channels,2,64)
        x1 = self.conv2(x1).view(y1.size(0),self.out_channels,8,8)
        attention = self.tanh(x1)
        x1 = torch.einsum('ncuv,nctv->nctu', attention, x3)
        x1 = self.bn(x1)
        x1 = self.relu(x1)
        x1 = x1.permute(0,2,1,3).contiguous()
        x1 = self.tcnA1(x1)
        return x1
    

class CTRGC(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(CTRGC, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.chomp1 = Chomp1d(chomp_size=1)
        self.convs = nn.ModuleList()
        for i in range(8):
            self.convs.append(TemporalConvNet(100, num_channels=[128,64]))
        self.tanh = nn.Tanh()
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                conv_init(m)
            elif isinstance(m, nn.BatchNorm2d):
                bn_init(m, 1)

    def forward(self, x, A=None, alpha=0.5):
        node_outs_1 = []
        x = x.permute(0,3,1,2)
        #x = x.unsqueeze(4)
        for i in range(8):
            x1 = self.convs[i](x[:,i,:,:])
            #x1 = self.chomp1(x1)
            x1 = x1.unsqueeze(1)
            node_outs_1.append(x1)
        out_1 = torch.cat(node_outs_1, dim=1)
        #out_1 = out_1.permute(0,2,3,1)
        return out_1
    
class unit_tcn(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=9, stride=1):
        super(unit_tcn, self).__init__()
        pad = int((kernel_size - 1) / 2)
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=(kernel_size, 1), padding=(pad, 0),
                              stride=(stride, 1))

        self.bn = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)
        conv_init(self.conv)
        bn_init(self.bn, 1)

    def forward(self, x):
        x = self.bn(self.conv(x))
        x = self.bn(x)
        x = self.relu(x)
        return x
    
class unit_gcn_1(nn.Module):
    def __init__(self, in_channels, out_channels, A, coff_embedding=4, adaptive=True, residual=True):
        super(unit_gcn_1, self).__init__()
        self.adaptive = adaptive
        self.num_subsetA = A.shape[0]
        self.num_subset = 3
        self.convsA = nn.ModuleList()
        for i in range(self.num_subset):
            self.convsA.append(CTRGC_1(in_channels, out_channels))
        
        if residual:
            if in_channels != out_channels:
                self.down1 = nn.Sequential(
                    nn.Conv2d(in_channels, out_channels, 1),
                    nn.BatchNorm2d(out_channels)
                )

                self.down2 = nn.Sequential(
                    nn.Conv2d(in_channels, out_channels, 1),
                    nn.BatchNorm2d(out_channels)
                )
                
            else:
                self.down1 = lambda x: x
                self.down2 = lambda x: x
        else:
            self.down1 = lambda x: 0
            self.down2 = lambda x: 0
            
        if self.adaptive:
            self.PA = nn.Parameter(A)
        else:
            self.A = Variable(torch.from_numpy(A.astype(np.float32)), requires_grad=False)
            
            
        self.alpha1 = nn.Parameter(torch.zeros(3,1))
        self.bn = nn.BatchNorm2d(out_channels)
        self.soft = nn.Softmax(-2)
        self.relu = nn.ReLU(inplace=True)

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                conv_init(m)
            elif isinstance(m, nn.BatchNorm2d):
                bn_init(m, 1)
        bn_init(self.bn, 1e-6)

    def forward(self, x):
        y = None
        if self.adaptive:
            A = self.PA
        else:
            A = self.A.cuda(x.get_device())
        for i in range(self.num_subset):
            z = self.convsA[i](x, A, self.alpha1)
            y = z + y if y is not None else z
        y = self.bn(y)
        #y = self.relu(y)
        return y
    
class unit_gcn(nn.Module):
    def __init__(self, in_channels, out_channels, pro2=0.5, al2=0.1):
        super(unit_gcn, self).__init__()
        self.convsA = CTRGC(in_channels, out_channels)
            
        self.bn = nn.BatchNorm2d(out_channels)
        self.data_bn = MixStyle_1d(p=pro2, alpha=al2)
        self.relu = nn.ReLU(inplace=True)

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                conv_init(m)
            elif isinstance(m, nn.BatchNorm2d):
                bn_init(m, 1)
        bn_init(self.bn, 1e-6)

    def forward(self, x):
        y = self.convsA(x)
        B,N,C,T = y.size()
        y = self.data_bn(y.view(B,N*C,T))
        y = y.view(B,N,C,T)
        y = y.permute(0,2,3,1).contiguous()
        y = self.relu(y)

        return y
    
class TCN_GCN_unit(nn.Module):
    def __init__(self, in_channels, out_channels, A, stride=1, residual=True, adaptive=True, kernel_size=5, dilations=[1,2], t_in_channels=1, t_out_channels=1, pro2=0.5, al2=0.1):
        super(TCN_GCN_unit, self).__init__()
        self.gcn1 = unit_gcn(in_channels, out_channels, pro2=pro2, al2=al2)
        self.tcnA1 = MultiScale_TemporalConv(t_in_channels, t_out_channels)
        self.tcnA2 = MultiScale_TemporalConv_1(t_in_channels, t_out_channels, kernel_size=kernel_size, stride=stride, dilations=dilations,
                                            residual=False)
        self.relu = nn.ReLU(inplace=True)
        self.data_bn = MixStyle_1d(p=0, alpha=0.1)
        if not residual:
            self.residual = lambda x: 0

        elif (in_channels == out_channels) and (stride == 1):
            self.residual = lambda x: x

        else:
            self.residual = unit_tcn(in_channels, out_channels, kernel_size=1, stride=stride)

    def forward(self, x):
        yA = self.gcn1(x)
        yA = yA.permute(0,1,3,2).contiguous()
        yA = yA.permute(0,3,1,2).contiguous()
        
        return yA
    
class TCN_GCN_unit_1(nn.Module):
    def __init__(self, in_channels, out_channels, A, stride=1, residual=True, adaptive=True, kernel_size=5, dilations=[1,2], t_in_channels=1, t_out_channels=1):
        super(TCN_GCN_unit_1, self).__init__()
        self.gcn1 = unit_gcn_1(in_channels, out_channels, A, adaptive=adaptive)
        self.tcnA1 = MultiScale_TemporalConv(t_in_channels, t_out_channels)
        self.tcnA2 = MultiScale_TemporalConv_1(800, 144, kernel_size=kernel_size, stride=stride, dilations=dilations,
                                            residual=False)
        self.relu = nn.ReLU(inplace=True)
        if not residual:
            self.residual = lambda x: 0

        elif (in_channels == out_channels) and (stride == 1):
            self.residual = lambda x: x

        else:
            self.residual = unit_tcn(in_channels, out_channels, kernel_size=1, stride=stride)

    def forward(self, x):
        x = self.tcnA2(x)
        x = x.permute(0,2,1,3).contiguous()
        x = self.gcn1(x)
        x = x.permute(0,2,1,3).contiguous()
        
        return x
    
def deactivate_mixstyle(m):
    if type(m) == MixStyle_1d:
        m.set_activation_status(False)

def activate_mixstyle(m):
    if type(m) == MixStyle_1d:
        m.set_activation_status(True)

class MixStyle_1d(nn.Module):
    """MixStyle.
    Reference:
      Zhou et al. Domain Generalization with MixStyle. ICLR 2021.
    """

    def __init__(self, p=0.5, alpha=0.1, eps=1e-6, mix='crossdomain_multi_match', d=5, num_class=6, samples_per_class=5):
        """
        Args:
          p (float): probability of using MixStyle.
          alpha (float): parameter of the Beta distribution.
          eps (float): scaling parameter to avoid numerical issues.
          mix (str): how to mix.
        """
        super().__init__()
        self.p = p
        self.beta = torch.distributions.Beta(alpha, alpha)
        self.eps = eps
        self.alpha = alpha
        self.mix = mix
        self._activated = True
        self.domain_num = d
        self.num_classes = num_class
        self.samples_per_class = samples_per_class


    def __repr__(self):
        return f'MixStyle(p={self.p}, alpha={self.alpha}, eps={self.eps}, mix={self.mix})'

    def set_activation_status(self, status=True):
        self._activated = status

    def update_mix_method(self, mix='random'):
        self.mix = mix

    def forward(self, x):
        if not self.training or not self._activated:
            return x

        if random.random() > self.p:
            return x

        B = x.size(0)

        #mu = x.mean(dim=[2, 3], keepdim=True)
        mu = x.mean(dim=[2], keepdim=True)
        #var = x.var(dim=[2, 3], keepdim=True)
        var = x.var(dim=[2], keepdim=True)
        
        sig = (var + self.eps).sqrt()
        mu, sig = mu.detach(), sig.detach()
        x_normed = (x-mu) / sig
        
        lmda = self.beta.sample((B, 1, 1))
        lmda = lmda.to(x.device)

        if self.mix == 'random':
            # random shuffle
            perm = torch.randperm(B)

        elif self.mix == 'crossdomain':
            # split into two halves and swap the order
            perm = torch.arange(B - 1, -1, -1) # inverse index
            perm_b, perm_a = perm.chunk(2)
            perm_b = perm_b[torch.randperm(B // 2)]
            perm_a = perm_a[torch.randperm(B // 2)]
            perm = torch.cat([perm_b, perm_a], 0)

        elif self.mix == 'crossdomain_multi':
            perm = torch.arange(B - 1, -1, -1)  
            perm_parts = perm.chunk(self.domain_num) 

            
            perm_parts = [part[torch.randperm(len(part))] for part in perm_parts]
            
            
            perm = torch.cat(perm_parts, 0)

        elif self.mix == 'crossdomain_multi_match':
            perm_parts = []

           
            for domain_idx in range(self.domain_num):
                domain_perms = []  

                
                for class_idx in range(self.num_classes):
                    
                    start_idx = domain_idx * self.num_classes * self.samples_per_class + class_idx * self.samples_per_class
                    end_idx = start_idx + self.samples_per_class

                    
                    class_perm = torch.arange(start_idx, end_idx)
                    class_perm = class_perm[torch.randperm(self.samples_per_class)]
                    domain_perms.append(class_perm)

                
                perm_parts.append(torch.cat(domain_perms))

            
            domain_perm_order = torch.randperm(self.domain_num)
            perm_parts = [perm_parts[i] for i in domain_perm_order]

            
            perm = torch.cat(perm_parts)

        else:
            raise NotImplementedError

        mu2, sig2 = mu[perm], sig[perm]
        mu_mix = mu*lmda + mu2 * (1-lmda)
        sig_mix = sig*lmda + sig2 * (1-lmda)

        return x_normed*sig_mix + mu_mix
    
class Model(nn.Module):
    def __init__(self, num_classA=6, num_point=6, in_channels=121, drop_out=0.5, adaptive=True, hparams2=None):
        super(Model, self).__init__()
        
        A = torch.randn(5,6,6)
        B = torch.randn(3,6,6)
        #C = torch.randn(2,6,6)
        
        self.num_classA = num_classA
        self.num_point = num_point#这里应该改为6
        self.data_bn = nn.BatchNorm1d(in_channels * num_point)
        self.data_bn1 = nn.InstanceNorm1d(num_features=in_channels * num_point, affine=True)
        self.data_bn2 = MixStyle_1d(p=hparams2['pro1'], alpha=hparams2['al1'])
        
        
        base_channel = 64
        out_channel = 16
        
        self.l1 = TCN_GCN_unit(in_channels, base_channel, A, residual=True, adaptive=adaptive, t_in_channels=800, t_out_channels=64, pro2=hparams2['pro2'], al2=hparams2['al2'])#这里默认的in_channels要改为30
        self.l2 = TCN_GCN_unit_1(base_channel, out_channel, B, residual=False, adaptive=adaptive, t_in_channels=64, t_out_channels=16)
        
        self.fcA = nn.Linear(16, num_classA)
        
        nn.init.normal_(self.fcA.weight, 0, math.sqrt(2. / num_classA))
        
        bn_init(self.data_bn, 1)
        bn_init(self.data_bn1, 1)
        
        if drop_out:
            self.drop_out = nn.Dropout(drop_out)
        else:
            self.drop_out = lambda x: x

    def forward(self, x):
        x = x.squeeze(dim=-1)
        #x = x.permute(0,2,3,1,4)
        N, V, C, T = x.size()
        x = x.view(N, V * C, T)
        #x = x.permute(0, 4, 3, 1, 2).contiguous().view(N, M * V * C, T)
        x = self.data_bn2(x)
        x = x.view(N, V, C, T).permute(0, 2, 3, 1).contiguous()
        #print(x.size())
        xA = self.l1(x)
        xA = self.l2(xA)
        c_new = xA.size(2)
        xA = xA.permute(0,2,1,3).contiguous().view(N, c_new, -1)
        #print(xA.size())
        xA = xA.mean(2)
        xA = self.drop_out(xA)
        xA = self.fcA(xA)
        return xA




