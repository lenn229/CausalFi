# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved
import os
import torch


import numpy as np
import scipy.io as scio
import torch.utils.data as Data
import random




DATASETS = [
    "WiFi_New",
    "WiFi_New_causal",
    "WiFi_simple_try"
]
seed = 0
random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)

def get_dataset_class(dataset_name):
    """Return the dataset class with the given name."""
    if dataset_name not in globals():
        raise NotImplementedError("Dataset not found: {}".format(dataset_name))
    return globals()[dataset_name]


def num_environments(dataset_name):
    return len(get_dataset_class(dataset_name).ENVIRONMENTS)


class MultipleDomainDataset:
    N_STEPS = 5001           # Default, subclasses may override
    CHECKPOINT_FREQ = 100    # Default, subclasses may override
    N_WORKERS = 0            # Default, subclasses may override
    ENVIRONMENTS = None      # Subclasses should override
    INPUT_SHAPE = None       # Subclasses should override

    def __getitem__(self, index):
        return self.datasets[index]

    def __len__(self):
        return len(self.datasets)

def generate_train_paths(image_base_dir):
    img_paths = []
    img_labels1 = []
    all_image_paths = [os.path.join(image_base_dir,i) for i in os.listdir(image_base_dir)]
    for img_path in all_image_paths:
        if img_path[48] == '3':
            img_paths.append(str(img_path))
    for i in os.listdir(image_base_dir):
        if i[4] != '5':
            if int(i[11]) == 3:
                img_labels1.append(int(i[7])-1)
        else:
            if int(i[10]) == 3:
                img_labels1.append(int(i[6])-1)
    return img_paths,img_labels1



def generate_train_paths_New(image_base_dir):
    img_paths = []
    img_labels1 = []
    all_image_paths = []
    for i in os.listdir(image_base_dir):
        if i == 'figure':
            continue
        path = os.path.join(image_base_dir, i)
        all_image_paths.append(path)
    for img_path in all_image_paths:
        #if img_path[44] == '1':
            #if img_path[46] == '1':
            img_paths.append(str(img_path))
    for i in os.listdir(image_base_dir):
        if i == 'figure':
            continue
        #if int(i[11]) == 1:
            #if int(i[11]) == 1:
        img_labels1.append(int(i[7])-1)
    return img_paths,img_labels1


def generate_train_paths_causal(image_base_dir,label,loc,ori):
    img_paths = []
    img_labels1 = []
    all_image_paths = []
    for i in os.listdir(image_base_dir):
        if i == 'figure':
            continue
        path = os.path.join(image_base_dir, i)
        all_image_paths.append(path)
        
    for img_path in all_image_paths:
        if int(img_path[40]) == int(label):
            if int(img_path[42]) == int(loc):
                if int(img_path[44]) == int(ori):
                    img_paths.append(str(img_path))
    for i in os.listdir(image_base_dir):
        if i == 'figure':
            continue
        if int(i[7]) == int(label):
            if int(i[9]) == int(loc):
                if int(i[11]) == int(ori):
                    img_labels1.append(int(i[7])-1)
    return img_paths,img_labels1




def WiFi_Folder_New(path):
    train_video_feature = []
    train_video_label1 = []
    i = 1
    img_paths,img_labels1 = generate_train_paths_New(path)
    for dataFile in img_paths:
        #print(dataFile)
        data_1 = scio.loadmat(dataFile)
        #data_array_1 = np.zeros((1, 100, 800), dtype=np.float32)
        data_array_1 = np.zeros((8, 100, 800), dtype=np.float32)
        #data_array_1[:, :,:data_1['dfs_sp'].shape[2]] = data_1['dfs_sp'][1,:,:]
        data_array_1[:, :,:data_1['dfs_sp'].shape[2]] = data_1['dfs_sp']
        train_video_feature.append(data_array_1)
        train_video_label1.append(img_labels1[i-1])

        i = i + 1
            

    train_video_feature = np.array(train_video_feature)
    train_video_label1 = np.array(train_video_label1)
    train_video_feature = torch.from_numpy(train_video_feature)
    train_video_label1 = torch.from_numpy(train_video_label1)

    train_dataset = Data.TensorDataset(train_video_feature, train_video_label1)

    return train_dataset

def WiFi_Folder_New_causal(image_base_dir, label, loc, ori, label_env_relationship_array, Po):
    train_video_feature = []
    train_video_label1 = []
    #for image_base_dir in image_base_dirs1:
        
    i = 1
    img_paths,img_labels1 = generate_train_paths_causal(image_base_dir,label,loc,ori)
    for dataFile in img_paths:
        if label_env_relationship_array[label-1][loc-1][ori-1] == True:
            if random.random() < Po:
                #print(dataFile)
                data_1 = scio.loadmat(dataFile)
                data_array_1 = np.zeros((8, 100, 800), dtype=np.float32)
                data_array_1[:, :,:data_1['dfs_sp'].shape[2]] = data_1['dfs_sp']
                data_array_1 = data_array_1[[0,2,4,6,7,5,3,1],:,:]
                train_video_feature.append(data_array_1)
                train_video_label1.append(img_labels1[i-1])
        else:
            if random.random() < 1-Po:
                #print(dataFile)
                data_1 = scio.loadmat(dataFile)
                data_array_1 = np.zeros((8, 100, 800), dtype=np.float32)
                data_array_1[:, :,:data_1['dfs_sp'].shape[2]] = data_1['dfs_sp']
                data_array_1 = data_array_1[[0,2,4,6,7,5,3,1],:,:]
                train_video_feature.append(data_array_1)
                train_video_label1.append(img_labels1[i-1])
                
        if len(train_video_feature) == 0 and i == len(img_paths):
            #print(dataFile)
            data_1 = scio.loadmat(dataFile)
            data_array_1 = np.zeros((8, 100, 800), dtype=np.float32)
            data_array_1[:, :,:data_1['dfs_sp'].shape[2]] = data_1['dfs_sp']
            data_array_1 = data_array_1[[0,2,4,6,7,5,3,1],:,:]
            train_video_feature.append(data_array_1)
            train_video_label1.append(img_labels1[i-1])
            
        i = i + 1
            
    train_video_feature = np.array(train_video_feature)
    train_video_label1 = np.array(train_video_label1)

    return train_video_feature,train_video_label1




class MultipleEnvironmentImageFolder_WiFi_New(MultipleDomainDataset):
    def __init__(self, root, test_envs, hparams):
        super().__init__()
        environments = ['data_for_yn_V1','data_for_ch_V1','data_for_zj_V1','data_for_wt_V1','data_for_wq_V1','data_for_yl_V1']
        self.datasets = []
        

        for i, environment in enumerate(environments):

            path = os.path.join(root, environment)
            
            env_dataset = WiFi_Folder_New(path)

            self.datasets.append(env_dataset)
            
            print('finish %d' %i)
            
        self.input_shape = (1, 100, 800,)
        
        self.num_classes = 6




class MultipleEnvironmentImageFolder_WiFi_New_causal(MultipleDomainDataset):
    def __init__(self, root, test_envs, hparams, label_env_relationship_array_train, Po, label_env_relationship_array_test, Poi, seed):
        super().__init__()
        environments = ['data_for_yn_V1','data_for_ch_V1','data_for_zj_V1','data_for_wt_V1','data_for_wq_V1','data_for_yl_V1']
        self.datasets = []
        iii = 0

        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)

        for times, environment in enumerate(environments):
            path = os.path.join(root, environment)
            if times not in test_envs:
                train_feature = []
                train_label = []
                for i in range(1, 7):
                    for j in range(1, 6):
                        for k in range(1, 7):
                            single_feature, single_label = WiFi_Folder_New_causal(path, i, j, k, label_env_relationship_array_train[iii], Po)
                            if len(single_feature) == 0: 
                                continue

                            if len(train_feature) == 0:
                                train_feature = single_feature
                                train_label = single_label
                            else:               
                                train_feature = np.concatenate((train_feature, single_feature), axis=0)
                                train_label = np.concatenate((train_label, single_label), axis=0)

                train_feature = torch.from_numpy(train_feature)
                train_label1 = torch.from_numpy(train_label)
                train_data = (train_feature.unsqueeze(4)).to(torch.float32)
                env_dataset = Data.TensorDataset(train_data, train_label1)

                self.datasets.append(env_dataset)
                iii = iii + 1
                print('finish %d' %times)

            else:
                test_feature = []
                test_label = []
                for i in range(1, 7):
                    for j in range(1, 6):
                        for k in range(1, 7):
                            single_feature, single_label = WiFi_Folder_New_causal(path, i, j, k, label_env_relationship_array_test, Poi)
                            if len(single_feature) == 0: 
                                continue
                                
                            if len(test_feature) == 0:
                                test_feature = single_feature
                                test_label = single_label
                            else:               
                                test_feature = np.concatenate((test_feature, single_feature), axis=0)
                                test_label = np.concatenate((test_label, single_label), axis=0)
            
                test_feature = torch.from_numpy(test_feature)
                test_label1 = torch.from_numpy(test_label)
                test_data = (test_feature.unsqueeze(4)).to(torch.float32)
                env_dataset_test = Data.TensorDataset(test_data, test_label1)
                self.datasets.append(env_dataset_test)
                
                print('finish %d' %times)


        self.input_shape = (1, 100, 800,)
        
        self.num_classes = 6





class WiFi_New(MultipleEnvironmentImageFolder_WiFi_New):
    CHECKPOINT_FREQ = 300
    ENVIRONMENTS = ["0", "1", "2", "3","4","5"]
    def __init__(self, root, test_envs, hparams):
        self.dir = os.path.join(root)
        super().__init__(self.dir, test_envs, hparams)


class WiFi_New_causal(MultipleEnvironmentImageFolder_WiFi_New_causal):
    CHECKPOINT_FREQ = 300
    ENVIRONMENTS = ["0", "1", "2", "3","4","5"]
    def __init__(self, root, test_envs, hparams, label_env_relationship_array_train, Po, label_env_relationship_array_test, Poi, seed):
        self.dir = os.path.join(root)
        super().__init__(self.dir, test_envs, hparams, label_env_relationship_array_train, Po, label_env_relationship_array_test, Poi, seed)



class WiFi_simple_try(MultipleDomainDataset):
    """
    Minimal synthetic dataset:
    - 6 environments, 6 classes (labels 0..5)
    - Feature tensor shape per sample: [8, 100, 800, 1] (created via unsqueeze(4))
    """
    CHECKPOINT_FREQ = 300
    ENVIRONMENTS = ["0", "1", "2", "3", "4", "5"]

    def __init__(self):
        super().__init__()

        # Optional trailing seed in *args (e.g., ..., 0). Defaults to 0.
        seed = 0

        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)

        # Fixed synthetic config (kept small so can run quickly)
        SAMPLES_PER_CLASS = 120
        NOISE_STD = 0.05
        SIGNAL_AMP = 0.30
        CHANNELS, FREQ_BINS, TIME_STEPS = 8, 100, 800

        self.datasets = []
        for env_idx in range(6): #simulated environments
            X_list, y_list = [], []

            for cls in range(6): #simulated labels
                Xc = self._synthesize_block(
                    n=SAMPLES_PER_CLASS,
                    cls=cls,
                    env=env_idx,
                    base_seed=seed,
                    amp=SIGNAL_AMP,
                    noise=NOISE_STD,
                    C=CHANNELS,
                    F=FREQ_BINS,
                    T=TIME_STEPS
                )  # shape: [n, 8, 100, 800]
                yc = np.full((SAMPLES_PER_CLASS,), cls, dtype=np.int64)
                X_list.append(Xc)
                y_list.append(yc)

            X = np.concatenate(X_list, axis=0)  # [N, 8, 100, 800]
            y = np.concatenate(y_list, axis=0)  # [N]

            # Lightweight shuffle per environment
            idx = np.arange(len(y))
            rng = np.random.RandomState(seed + 1000 + env_idx)
            rng.shuffle(idx)
            X, y = X[idx], y[idx]

            # To Torch: [N, 8, 100, 800, 1]
            X_t = torch.from_numpy(X).unsqueeze(4).to(torch.float32)
            y_t = torch.from_numpy(y).to(torch.long)

            self.datasets.append(Data.TensorDataset(X_t, y_t))
            print(f'[WiFi_simple_try] env {env_idx}: {len(y)} samples')

        
        self.input_shape = (1, 100, 800)
        self.num_classes = 6

    def _synthesize_block(self, n, cls, env, base_seed, amp, noise, C, F, T):
        """
        Generate [n, C, F, T] synthetic samples:
        - A simple separable sine pattern encodes (env -> time freq) and (cls -> freq freq)
        - Additive Gaussian noise;
        """
        rng = np.random.RandomState(base_seed + env * 100 + cls)

        # Base noise
        X = rng.normal(0.0, noise, size=(n, C, F, T)).astype(np.float32)

        # Separable sine pattern
        t = np.linspace(0, 1, T, dtype=np.float32)         # time axis
        f = np.linspace(0, 1, F, dtype=np.float32)         # freq axis
        wave_t = np.sin(2 * np.pi * (1 + env) * t)         # (T,)
        wave_f = np.sin(2 * np.pi * (1 + cls) * f)         # (F,)
        patt = np.outer(wave_f, wave_t).astype(np.float32) # (F, T)

        # Expand to channels with simple fixed weights
        ch_w = np.linspace(1.0, 0.7, C, dtype=np.float32).reshape(C, 1, 1)  # (C,1,1)
        patt_ch = patt[None, ...] * ch_w                                    # (C,F,T)

        # Add pattern
        X += amp * patt_ch[None, ...]  # (n,C,F,T)

        return X


