from domainbed.lib import misc



class IndexWrapper:
    def __init__(self, dataset, use_raw_index=False):
        super().__init__()
        self.dataset = dataset
        if use_raw_index and isinstance(self.dataset, misc._SplitDataset):
            self.idx_map = self.dataset.keys
        else:
            self.idx_map = None
    
    def __getitem__(self, index):
        x, y = self.dataset[index]
        if self.idx_map is not None:
            index = self.idx_map[index]
        return index, x, y

    def __len__(self):
        return len(self.dataset)
