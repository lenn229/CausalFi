
import time, copy
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from domainbed.match.utils import IndexWrapper

@torch.no_grad()
def eval_mse(network, loader, d, weights, device, Node_num):
    weights_offset = 0
    weighted_mse = 0.0
    network.eval()
    for x, y in loader:
        x = x.to(device)
        y = y.to(device)
        batch_size = len(x)
        mse = 0
        for n in range(Node_num):
            recon_x = network.reconstruct(x[:,n,:,:], y, d, n)
            mse = mse + torch.mean(torch.nn.functional.mse_loss(
                recon_x.view(batch_size, -1), x[:,n,:,:].view(batch_size, -1), reduction='none'), -1)
        mse = mse/Node_num
        if weights is None:
            batch_weights = torch.ones(batch_size, device=device)
        else:
            batch_weights = weights[weights_offset : weights_offset + batch_size]
            weights_offset += batch_size
        batch_weights = batch_weights.to(device)
        weighted_mse += (torch.sum(mse * batch_weights)/torch.sum(batch_weights)).item()
    network.train()
    return weighted_mse/len(loader)

@torch.no_grad()
def eval_acc(network, loader, weights, num_classes, env, device, Node_num):
    weights_offset = 0
    correct = 0
    total = 0
    network.eval()
    for x, y in loader:
        x = x.to(device); y = y.to(device)
        batch_size = len(x)
        mse_list = []
        for i in range(num_classes):
            l = torch.zeros(len(x), dtype = torch.int64, device=device) + i
            mse = 0
            for n in range(Node_num):
                z = network.get_z(x[:,n,:,:], y, env, n)
                result = network.inference(z, l, n)
                mse = mse+torch.mean(torch.nn.functional.mse_loss(
                    result['recon_x'].view(batch_size, -1), x[:,n,:,:].view(batch_size, -1), reduction='none'), -1)
            mse = mse/Node_num
            mse_list.append(mse)
        pred_y = torch.argmin(torch.stack(mse_list, 1), 1)
        if weights is None:
            batch_weights = torch.ones(batch_size, device=device)
        else:
            batch_weights = weights[weights_offset : weights_offset + batch_size]
            weights_offset += batch_size
        correct += ((y == pred_y).float() * batch_weights).sum().item()
        total += batch_weights.sum().item()
    network.train()
    return correct / total

def get_final_b(all_ids):
    final_b = []
    for k_env, env_list in enumerate(all_ids):
        b = []
        for i, tensor in enumerate(env_list):
            for j, value in enumerate(tensor):
                b.append((value.item(), (i, j)))
        b.sort()
        final_b.append(b)
    return final_b

def wrap_datasets_new(in_splits, matcher, num_classes, batch_size=32,
                dist_func='l2', device="cuda", verbose=False, use_raw_index=False, 
                threshold=False, topk=1, num_cf=1):
    torch.multiprocessing.set_sharing_strategy('file_system')
    all_vars = []
    all_ids = []
    print("use ", dist_func, " distance.")
    for env, (dataset, weight) in enumerate(in_splits):
        print("processing environment ", env)
        x = [[] for _ in range(num_classes)]
        ids = [[] for _ in range(num_classes)]
        vars = []
        idid = []
        if verbose:
            print("total number of data: ", len(dataset))
        start_time = time.time()
        dataloader = DataLoader(IndexWrapper(dataset, use_raw_index), 
                batch_size=batch_size, shuffle=False, num_workers=4, drop_last=False)
        y_counts = torch.zeros(num_classes, dtype=torch.int64, device=device)
        for index_batch, x_batch, y_batch in dataloader:
            index_batch_, x_batch_, y_batch_ = copy.deepcopy(index_batch), copy.deepcopy(x_batch), copy.deepcopy(y_batch)
            for i, x_, y_ in zip(index_batch_, x_batch_, y_batch_):
                y_counts[int(y_)] += 1
                x[y_].append(x_)
                ids[y_].append(i)
        del dataloader
        print("data loading time: ", time.time() - start_time)
        x = [torch.stack(x_y, 0) for x_y in x]
        y = [torch.zeros(len(x[i]), dtype=torch.int64) + i for i in range(num_classes)]
        idi = [torch.stack(iii, 0) for iii in ids]
        p_y = y_counts/torch.sum(y_counts)
        if verbose:
            print("x sizes: ", [x_y.size() for x_y in x])
            print("y sizes: ", [_y.size() for _y in y])
            print("y counts: ", [int(_yc) for _yc in y_counts])
            print("p(y): ", p_y)
        start_time = time.time()
        matcher.eval()
        with torch.no_grad():
            for x_, y_, ids_ in zip(x,y,idi):
                i = 0
                temp_vars = []
                temp_ids = []
                while i < len(x_):
                    j = min(i+batch_size, len(x_))
                    temp_vars.append(matcher.propensity_score(x_[i:j].to(device), env, p_y).detach())
                    temp_ids.append(ids_[i:j])
                    i = j
                temp_vars = torch.cat(temp_vars, 0)
                temp_ids = torch.cat(temp_ids, 0)
                vars.append(temp_vars)
                idid.append(temp_ids)
        matcher.train()
        print("latent variables inference time: ", time.time() - start_time)
        all_vars.append(vars)
        all_ids.append(idid)
    return all_vars, all_ids
