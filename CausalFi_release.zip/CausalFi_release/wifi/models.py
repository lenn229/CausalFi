
import torch
import torch.nn as nn

from domainbed import WiFi_Network_Newdata_mixstylev3_drop as WiFi_Network_Newdata
from domainbed.WiFi_Network_Newdata_mixstylev3_drop import activate_mixstyle, deactivate_mixstyle

class Algorithm_New(torch.nn.Module):
    def __init__(self, input_shape, num_classes, num_domains, hparams):
        super().__init__()
        self.hparams = hparams
    def update(self, minibatches, unlabeled=None):
        raise NotImplementedError
    def predict(self, x):
        raise NotImplementedError

class WiFi_ERM_New(Algorithm_New):
    def __init__(self, train_only_in_split, X_all, Y_all, Score_all, device, 
                 input_shape, num_classes, num_domains, hparams, all_vars, final_b, hparams2):
        super().__init__(input_shape, num_classes, num_domains, hparams2)
        self.network = WiFi_Network_Newdata.Model(hparams2=hparams2)
        self.criterion = nn.CrossEntropyLoss()
        self.optimizer = torch.optim.Adam(self.network.parameters(), lr=0.001)
        self.train_dataset = train_only_in_split
        self.device = device
        self.X_all = X_all
        self.Y_all = Y_all
        self.Score_all = Score_all
        self.all_vars = all_vars
        self.final_b = final_b

    def activate(self):
        self.network.apply(activate_mixstyle)
    def deactivate(self):
        self.network.apply(deactivate_mixstyle)

    def update(self, minibatches, unlabeled=None):
        from algo_match import optimal_action
        optimal_X_batch = torch.tensor([])
        optimal_Y_batch = torch.tensor([])
        for env_i, (index,x,y) in enumerate(minibatches):
            t_batch = x.shape[0]
            t_extra = t_batch
            optimal_x, optimal_y = optimal_action(self.X_all[env_i], self.Y_all[env_i], self.Score_all[env_i],
                                                  x, y, index, t_batch, t_extra, env_i, self.all_vars, self.final_b)
            optimal_X_batch = torch.cat([optimal_X_batch, optimal_x])
            optimal_Y_batch = torch.cat([optimal_Y_batch, optimal_y])
        loss = self.criterion(self.predict(optimal_X_batch.squeeze(dim=-1).to(self.device)),
                              optimal_Y_batch.long().to(self.device))
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        return {'loss': loss.item()}

    def predict(self, x):
        return self.network(x)
