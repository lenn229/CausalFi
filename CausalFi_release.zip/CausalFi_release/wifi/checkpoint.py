
import os
import torch

def save_checkpoint(filename, dataset, algorithm, args, hparams):
    if not getattr(args, 'save_model_every_checkpoint', False) and filename != 'model.pkl':
        return
    save_dict = {
        "args": vars(args),
        "model_input_shape": dataset.input_shape,
        "model_num_classes": dataset.num_classes,
        "model_num_domains": len(dataset) - len(args.test_envs),
        "model_hparams": hparams,
        "model_dict": algorithm.state_dict()
    }
    os.makedirs(args.output_dir, exist_ok=True)
    torch.save(save_dict, os.path.join(args.output_dir, filename))
