
import numpy as np, torch
from wifi.args import parse_train_network_args, parse_hparams_json
from processor_v2 import Processor

def main():
    args = parse_train_network_args()
    hparams = {}
    over = parse_hparams_json(args.hparams_json)
    hparams.update(over)
    hparams2 = {}
    hparams2.update(over)
    hparams2['batch_size'] = args.batch_size
    hparams2['batch_size_balanced'] = args.batch_size_balanced
    hparams2['steps'] = hparams2.get('steps', args.steps or 1000)
    torch.manual_seed(args.seed); np.random.seed(args.seed)

    proc = Processor(args, hparams, hparams2, device='cuda:0' if args.use_gpu else 'cpu')
    proc.load_data()
    matcher = proc.load_cvae_from_checkpoint(args.matcher_checkpoint, device=proc.device)
    all_vars, final_b = proc.compute_causal_scores(matcher, batch_size=hparams.get('batch_size', 32))
    proc.train_classifier(all_vars, final_b)

if __name__ == "__main__":
    main()
