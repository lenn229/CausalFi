# === NAMING NOTE (important for this file) ==============================
# Outer convention used by the caller of `optimal_action`:
#   - X_all / X_batch  : DFS FEATURES
#   - Y_all / Y_batch  : LABELS, ints in {0..5}
#   - Score_all        : SCORES (logits or probs), shape (..., 6)
#
# Inner convention used by other functions in THIS file:
#   - X_* : LABELS
#   - Y_* : SCORES
# Therefore:
#   outer labels  -> inner X_*
#   outer scores  -> inner Y_*
# ============================================================================


import torch

def index2score(all_vars,final_b,index_batch, env_i):
    score =[all_vars[env_i][final_b[env_i][idx][1][0]][final_b[env_i][idx][1][1]]  for idx in index_batch]
    return score

def softmax(x):
    """Compute softmax values for each sets of scores in x."""
    max_vals, _ = torch.max(x, dim=1, keepdim=True)
    e_x = torch.exp(x - max_vals)
    return e_x / torch.sum(e_x, dim=1, keepdim=True)

def compute_u_a(Y_t):
    """
    Compute u_a value using the provided formula.
    
    Parameters:
        Y_t (torch.Tensor): Input tensor with shape (T, 6).
        
    Returns:
        float: Computed u_a value.
    """

    # Y_t : (T, 6) SCORES (logits or unnormalized scores) for a subset.

    T = Y_t.shape[0]
    #y_t = softmax(Y_t)
    y_t = Y_t
    sum_y_t = torch.mean(y_t, dim=0)  # Summing along the T axis
    sum_y_t = softmax(sum_y_t.unsqueeze(0))
    
    u_a = -torch.sum(sum_y_t * torch.log(sum_y_t))
    
    return u_a.item(), sum_y_t  # Ensure the return is a float

def adjust_to_integer_sum(tensor, target_sum):
    """
    Adjust the elements of a tensor to be integers such that their sum equals the target sum.
    
    Args:
    tensor (torch.Tensor): The input tensor with floating-point values.
    target_sum (int): The desired sum of the output tensor elements.
    
    Returns:
    torch.Tensor: The adjusted tensor with integer values and the specified sum.
    """
    
    tensor_int = torch.floor(tensor).int()
    
    remainder = tensor - tensor_int
    total_remainder = target_sum - torch.sum(tensor_int)
    
    _, indices = torch.topk(remainder, total_remainder)
    
    
    tensor_int[indices] += 1
    
    assert torch.sum(tensor_int) == target_sum
    
    return tensor_int


def Renew1(feature_all_a, X_all_a, Y_all_a, feature_batch, X_batch, Y_batch, T_A_i):
    # Greedy ADD for a fixed class 'a' (when T_A[i] >= 0).
    # Semantics (inner):
    #   feature_all_a : candidate pool FEATURES
    #   X_all_a       : candidate pool LABELS
    #   Y_all_a       : candidate pool SCORES (…, 6)
    #   feature_batch : current sub-batch FEATURES
    #   X_batch       : current sub-batch LABELS
    #   Y_batch       : current sub-batch SCORES

    feature_batch_new = feature_batch.clone()
    X_batch_new = X_batch.clone()
    Y_batch_new = Y_batch.clone()

    for _ in range(T_A_i):
        max_reward = float('-inf')
        best_index = -1

        for i in range(Y_all_a.shape[0]):
            Y_temp = torch.cat((Y_batch_new, Y_all_a[i:i+1]), dim=0)
            reward,sum_y_t = compute_u_a(Y_temp)
            if reward > max_reward:
                max_reward = reward
                best_index = i
        
        if best_index != -1:
            feature_batch_new = torch.cat((feature_batch_new, feature_all_a[best_index:best_index+1]), dim=0)
            X_batch_new = torch.cat((X_batch_new, X_all_a[best_index:best_index+1]), dim=0)
            Y_batch_new = torch.cat((Y_batch_new, Y_all_a[best_index:best_index+1]), dim=0)
            
            feature_all_a = torch.cat((feature_all_a[:best_index], feature_all_a[best_index+1:]), dim=0)
            X_all_a = torch.cat((X_all_a[:best_index], X_all_a[best_index+1:]), dim=0)
            Y_all_a = torch.cat((Y_all_a[:best_index], Y_all_a[best_index+1:]), dim=0)

    reward,sum_y_t = compute_u_a(Y_batch_new)
    return reward, feature_batch_new, X_batch_new, Y_batch_new, sum_y_t


def Renew2(feature_batch_a, X_batch_a, Y_batch_a, T_A_i):
    # Greedy REMOVE for a fixed class 'a' (when T_A[i] < 0).
    # Semantics (inner):
    #   feature_batch_a : current sub-batch FEATURES
    #   X_batch_a       : current sub-batch LABELS
    #   Y_batch_a       : current sub-batch SCORES (…, 6)

    feature_batch_new = feature_batch_a.clone()
    X_batch_new = X_batch_a.clone()
    Y_batch_new = Y_batch_a.clone()

    
    for _ in range(abs(T_A_i)):
        max_reward = float('-inf')
        best_index = -1

        for i in range(Y_batch_new.shape[0]):
            Y_temp = torch.cat((Y_batch_new[:i], Y_batch_new[i+1:]), dim=0)
            reward, sum_y_t = compute_u_a(Y_temp)
            if reward > max_reward:
                max_reward = reward
                best_index = i
        
        if best_index != -1:
            feature_batch_new = torch.cat((feature_batch_new[:best_index], feature_batch_new[best_index+1:]), dim=0)
            X_batch_new = torch.cat((X_batch_new[:best_index], X_batch_new[best_index+1:]), dim=0)
            Y_batch_new = torch.cat((Y_batch_new[:best_index], Y_batch_new[best_index+1:]), dim=0)
        else:
            assert best_index == -1
    
    reward, sum_y_t = compute_u_a(Y_batch_new)
    return reward, feature_batch_new, X_batch_new, Y_batch_new, sum_y_t


def estimate_rewards_and_probabilities(X_batch, Y_batch, T_batch, T_extra):
    # ------------------------------------------------------------------
    # Semantics (inner):
    #   X_batch : LABELS (ints in {0..5})
    #   Y_batch : SCORES (T,6)


    A = torch.tensor([0, 1, 2, 3, 4, 5])
    rewards = torch.zeros_like(A, dtype=torch.float)
    sum_y_t = torch.zeros(6,6)
    probabilities = torch.zeros_like(A, dtype=torch.float)
    
    for i, a in enumerate(A):
        indices = torch.where(X_batch == a)[0]
        T_a = torch.sum(X_batch[indices] == a)
        rewards[i],sum_y_t[i] = compute_u_a(Y_batch[indices])
        probabilities[i] = T_a / T_batch

    c = T_extra / T_batch
    #print(probabilities.shape)
    T_A = (T_extra / len(A)) * (1 + (1-probabilities * len(A)) / c)
    T_A = adjust_to_integer_sum(T_A, T_extra)
    
    return A, T_A


def intervene_and_estimate(feature_all, X_all, Y_all, feature_batch, X_batch, Y_batch, A, T_A):
    # Semantics (inner):
    #   feature_all / feature_batch : DFS FEATURES (full pool / current batch)
    #   X_all / X_batch             : DFS LABELS   (full pool / current batch)
    #   Y_all / Y_batch             : Balancing SCORES   (full pool / current batch)
    # For each class 'a':
    #   - if T_A[a] >= 0: Renew1 (ADD)
    #   - else          : Renew2 (REMOVE)
    #   - concatenate per-class results back to full batch

    sum_y_t = torch.zeros(6,6)
    rewards = torch.zeros_like(A, dtype=torch.float)
    feature_batch_re = torch.tensor([])
    X_batch_re = torch.tensor([])
    Y_batch_re = torch.tensor([])
    for i, a in enumerate(A):
        indices_all = torch.where(X_all == a)[0]
        indices_batch = torch.where(X_batch == a)[0]
        

        if T_A[i] >= 0:
            reward, feature_batch_New, X_batch_New, Y_batch_New, sum_y_t[i] = Renew1(feature_all[indices_all], X_all[indices_all], Y_all[indices_all], feature_batch[indices_batch], X_batch[indices_batch], Y_batch[indices_batch], int(T_A[i].item()))
        else:
            reward, feature_batch_New, X_batch_New, Y_batch_New, sum_y_t[i] = Renew2(feature_batch[indices_batch], X_batch[indices_batch], Y_batch[indices_batch], int(T_A[i].item()))
        
        
        feature_batch_re = torch.cat((feature_batch_re, feature_batch_New))
        X_batch_re = torch.cat((X_batch_re, X_batch_New))
        Y_batch_re = torch.cat((Y_batch_re, Y_batch_New))

        rewards[i] = reward

    return rewards,feature_batch_re, X_batch_re, Y_batch_re, sum_y_t


def optimal_action(X_all, Y_all, Score_all, X_batch, Y_batch, Index_batch, T_batch, T_extra, env_i, all_vars,final_b):
    # Outer naming:
    #   X_all/X_batch   : FEATURES
    #   Y_all/Y_batch   : LABELS
    #   Score_all       : SCORES
    
    Score_batch_list = index2score(all_vars,final_b,Index_batch,env_i)
    Score_batch = torch.stack(Score_batch_list)
    X_all = torch.cat(X_all)
    Y_all = torch.cat(Y_all)
    Score_all = torch.stack(Score_all)

    #!!!
    # Here we respect the inner convention by passing!!!
    #   outer labels  -> inner X_*
    #   outer scores  -> inner Y_*
    

    # Call #1: outer labels -> inner X_batch; outer scores -> inner Y_batch
    A, T_A = estimate_rewards_and_probabilities(Y_batch.cpu(), Score_batch.cpu(), T_batch, T_extra)

    # Call #2: (feature_all, labels_all, scores_all, feature_batch, labels_batch, scores_batch, A, T_A, rewards_ori)
    rewards, X_batch_New, Y_batch_New, Score_batch_New, sum_y_t = intervene_and_estimate(X_all.cpu(),Y_all.cpu(), Score_all.cpu(),X_batch.cpu(), Y_batch.cpu(), Score_batch.cpu(), A, T_A)
    

    return X_batch_New, Y_batch_New

