
import argparse
import json

def add_common_args(p: argparse.ArgumentParser):
    p.add_argument('--data_dir', type=str, required=True)
    p.add_argument('--dataset', type=str, required=True)
    p.add_argument('--output_dir', type=str, required=True)
    p.add_argument('--test_envs', type=int, nargs='+', default=[])
    p.add_argument('--hparams_json', type=str, default=None,
                   help='JSON string for hparams (overrides defaults)')
    p.add_argument('--seed', type=int, default=0)
    p.add_argument('--trial_seed', type=int, default=0)  # kept for split seeding
    p.add_argument('--checkpoint_freq', type=int, default=100)
    p.add_argument('--save_model_every_checkpoint', action='store_true')

def parse_train_cvae_args():
    p = argparse.ArgumentParser('train-cvae')
    add_common_args(p)
    p.add_argument('--steps', type=int, default=None,
                   help='Number of steps; if None, use dataset default')
    p.add_argument('--holdout_fraction', type=float, default=0.2)
    p.add_argument('--uda_holdout_fraction', type=float, default=0.0)
    p.add_argument('--use_gpu', action='store_true')
    args = p.parse_args()
    return args

def parse_train_network_args():
    p = argparse.ArgumentParser('train-network')
    add_common_args(p)
    p.add_argument('--steps', type=int, default=None)
    p.add_argument('--holdout_fraction', type=float, default=0.2)
    p.add_argument('--uda_holdout_fraction', type=float, default=0.0)
    p.add_argument('--use_gpu', action='store_true')
    p.add_argument('--matcher_checkpoint', type=str, required=True,
                   help='Path to a pretrained CVAE checkpoint (model.pkl)')
    p.add_argument('--batch_size', type=int, default=15)
    p.add_argument('--batch_size_balanced', type=int, default=32)
    args = p.parse_args()
    return args

def parse_hparams_json(hparams_json):
    if not hparams_json:
        return {}
    try:
        return json.loads(hparams_json)
    except Exception as e:
        raise ValueError(f"Invalid --hparams_json: {e}")
