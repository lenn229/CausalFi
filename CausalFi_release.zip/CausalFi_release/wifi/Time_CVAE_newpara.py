import torch
import torch.nn.functional as F
import torch.nn as nn

class Algorithm(torch.nn.Module):
    """
    A subclass of Algorithm implements a generation algorithm.
    """
    def __init__(self, input_shape, num_classes, num_domains, hparams):
        super(Algorithm, self).__init__()
        self.hparams = hparams
        self.num_classes = num_classes
        self.encoder = None
        self.decoder = None
        self.z_prior = None
        self.optimizer = None

    def reparameterize(self, mu, log_var):

        std = torch.exp(0.5 * log_var)
        eps = torch.randn_like(std) # sample from standard normal distribution

        return mu + eps * std

    def forward(self, x, y=None, d=None):
        raise NotImplementedError

    def update(self, minibatches, unlabeled=None):
        """
        Perform one update step, given a list of (x, y) tuples for all
        environments.

        Admits an optional list of unlabeled minibatches from the test domains,
        when task is domain_adaptation.
        """
        raise NotImplementedError

    def get_match_var(self, x):
        raise NotImplementedError

    def reconstruct(self, x, y=None):
        raise NotImplementedError

    def inference(self, z, y=None):
        raise NotImplementedError
    
    def get_z(self, x):
        raise NotImplementedError
    


def idx2onehot(idx, n):

    assert torch.max(idx).item() < n

    if idx.dim() == 1:
        idx = idx.unsqueeze(1)
    onehot = torch.zeros(idx.size(0), n).to(idx.device)
    onehot.scatter_(1, idx, 1)
    
    return onehot

class MLP(nn.Module):
    """Just an MLP"""
    def __init__(self, n_inputs, n_outputs, hparams):
        super(MLP, self).__init__()
        self.input = nn.Linear(n_inputs, hparams['mlp_width'])
        self.dropout = nn.Dropout(hparams['mlp_dropout'])
        self.hiddens = nn.ModuleList([
            nn.Linear(hparams['mlp_width'], hparams['mlp_width'])
            for _ in range(hparams['mlp_depth']-2)])
        self.output = nn.Linear(hparams['mlp_width'], n_outputs)
        self.n_outputs = n_outputs

    def forward(self, x):
        x = self.input(x.view(len(x), -1))
        x = self.dropout(x)
        x = F.relu(x)
        for hidden in self.hiddens:
            x = hidden(x)
            x = self.dropout(x)
            x = F.relu(x)
        x = self.output(x)
        return x

class Encoder_New(nn.Module):

    def __init__(self, x_shape, num_classes, num_domains, 
                    hparams,N, conditional,use_mlp=True):

        super().__init__()
        
        self.num_classes = num_classes
        self.num_domains = num_domains
        self.conditional = conditional
        self.hparams = hparams
        self.use_mlp = use_mlp
        self.N = N
        self.hidden_layer_sizes = [121, 64]
        self.seq_len = 800
        
        layers = []
        in_channels = x_shape[1]
        for num_filters in self.hidden_layer_sizes:
            layers.append(nn.Conv1d(in_channels, num_filters, kernel_size=3, stride=2, padding=1))
            layers.append(nn.ReLU())
            in_channels = num_filters

        self.encoder_conv = nn.Sequential(*layers)
        conv_output_dim = self.hidden_layer_sizes[-1] * (self.seq_len // (2 ** len(self.hidden_layer_sizes)))
        self.fc1 = nn.Linear(conv_output_dim, self.hparams["latent_size"])
        self.fc2 = nn.Linear(conv_output_dim, self.hparams["latent_size"])
        
        
        if self.use_mlp:
            if self.conditional:
                input_shape = x_shape[0]*x_shape[1]*x_shape[2] + num_classes + num_domains + N
                
            else:
                input_shape = x_shape[0]*x_shape[1]*x_shape[2]
                
        else:
            input_shape = x_shape
        
        
        #self.featurizer = MLP(input_shape, hparams["mlp_width"], hparams)

        #if self.conditional and not self.use_mlp:
        self.class_embd = nn.Linear(num_classes, conv_output_dim)
        self.domain_embd = nn.Linear(num_domains, conv_output_dim)
        self.node_embd = nn.Linear(self.N, conv_output_dim)

        #self.linear_means = nn.Linear(self.featurizer.n_outputs, self.hparams["latent_size"])
        #self.linear_log_var = nn.Linear(self.featurizer.n_outputs, self.hparams["latent_size"])
        
    def forward(self, x, c=None, d=None, n=None):
        
        if self.conditional:
            d = torch.zeros_like(c) + d
            n = torch.zeros_like(c) + n
            c = idx2onehot(c, n=self.num_classes)
            d = idx2onehot(d, n=self.num_domains)
            n = idx2onehot(n, n=self.N)

        #if self.use_mlp:
            #if self.conditional:
                #x = torch.cat((x.view(len(x), -1), c, d, n), dim=-1)
            #else:
                #x = x.view(len(x), -1)
                
        x = self.encoder_conv(x.squeeze(-1))
        x = x.view(x.size(0), -1)
        #x = self.featurizer(x)

        c_embd = self.class_embd(c)
        d_embd = self.domain_embd(d)
        n_embd = self.node_embd(n)
        x = x + c_embd + d_embd + n_embd

        means = self.fc1(x)
        log_vars = self.fc2(x)

        return means, log_vars
    

class Decoder_New(nn.Module):
    def __init__(self, x_shape, num_classes, hparams, N, conditional, num_latent=1):
        super().__init__()

        self.num_classes = num_classes
        self.conditional = conditional
        self.hparams = hparams
        self.N = N
        self.hidden_layer_sizes = [121, 64]
        self.seq_len = 800
        
        
        if self.conditional:
            input_shape = self.hparams["latent_size"] * num_latent + num_classes + self.N
        else:
            input_shape = self.hparams["latent_size"] * num_latent

        #self.featurizer = MLP(input_shape, hparams["mlp_width"], hparams)
        #self.out_layer = nn.Linear(self.featurizer.n_outputs, x_shape[0] * x_shape[1]* x_shape[2])

        self.level_params = nn.Sequential(
            nn.Linear(self.hparams["latent_size"] * num_latent + num_classes + self.N, x_shape[1]),
            nn.ReLU(),
            nn.Linear(x_shape[1], x_shape[1])
        )
        
        #Residual
        self.fc3 = nn.Linear(self.hparams["latent_size"] * num_latent + num_classes + self.N, self.hidden_layer_sizes[-1] * (self.seq_len // (2 ** len(self.hidden_layer_sizes))))
        layers = []
        in_channels = self.hidden_layer_sizes[-1]
        for num_filters in reversed(self.hidden_layer_sizes[:-1]):
            layers.append(nn.ConvTranspose1d(in_channels, num_filters, kernel_size=3, stride=2, padding=1, output_padding=1))
            layers.append(nn.ReLU())
            in_channels = num_filters

        layers.append(nn.ConvTranspose1d(in_channels, x_shape[1], kernel_size=3, stride=2, padding=1, output_padding=1))
        layers.append(nn.ReLU())
        self.decoder_conv = nn.Sequential(*layers)

        #self.fc4 = nn.Linear(self.feat_dim, self.seq_len * self.feat_dim)
        self.conv1d_layer = nn.Conv1d(in_channels=x_shape[1], out_channels=x_shape[1], kernel_size=1)
        
    def forward(self, z, c=None, n=None):
        if self.conditional:
            n = torch.zeros_like(c) + n
            c = idx2onehot(c, n=self.num_classes)
            z = torch.cat((z, c), dim=-1)

            nc = idx2onehot(n, n=self.N)
            z = torch.cat((z, nc), dim=-1)

        #x = self.featurizer(z)
        #x = self.out_layer(x)
        level_vals = self.level_model(z)        
        outputs = level_vals
        residuals = self._get_decoder_residual(z)
        x = outputs + residuals
        
        x = x.view(-1, 100, 800)  # reshape to [batch_size, 100, 800]

        # Apply sigmoid to ensure values are in [0, 1]
        x = torch.sigmoid(x)

        # Normalize each time dimension slice
        x_sum = x.sum(dim=1, keepdim=True)
        x = x / (x_sum + 1e-7)  # adding a small epsilon to avoid division by zero

        x = x.view(-1, 80000) 

        return x
    
    def _get_decoder_residual(self, x):
        x = self.fc3(x.view(x.size(0), -1))
        x = x.view(x.size(0), self.hidden_layer_sizes[-1], -1)
        x = self.decoder_conv(x)
        #x = x.view(x.size(0), -1)  # Flatten
        x = self.conv1d_layer(x)
        residuals = x.view(x.size(0), 100, 800)
        return residuals

    def level_model(self, z):
        level_params = self.level_params(z)
        level_params = level_params.view(-1, 100, 1)
        ones_tensor = torch.ones(1, 1, self.seq_len, device=z.device)
        level_vals = level_params * ones_tensor
        return level_vals
    
class Cond_Prior_New(nn.Module):

    def __init__(self, num_classes, num_domains, hparams, N, latent_size=None, domain_vary=True, distribution='Gaussian'):

        super().__init__()
        
        self.num_classes = num_classes
        self.hparams = hparams
        self.domain_vary = domain_vary
        self.distribution = distribution
        self.N = N
        
        if self.distribution == 'Gaussian':
            if self.domain_vary:
                self.linear_means = nn.ModuleList()
                self.linear_log_var = nn.ModuleList()
                for i in range(num_domains):
                    self.linear_means.append(nn.Linear(num_classes+N, self.hparams["latent_size"]))
                    self.linear_log_var.append(nn.Linear(num_classes+N, self.hparams["latent_size"]))
            else:
                self.linear_means = nn.Linear(num_classes+N, self.hparams["latent_size"])
                self.linear_log_var = nn.Linear(num_classes+N, self.hparams["latent_size"])

        elif self.distribution == 'Gaussian_fixed_variance':
            if self.domain_vary:
                self.linear_means = nn.ModuleList()
                for i in range(num_domains):
                    self.linear_means.append(nn.Linear(num_classes+N, self.hparams["latent_size"]))
            else:
                self.linear_means = nn.Linear(num_classes+N, self.hparams["latent_size"])
            self.log_var = 0.0

        elif self.distribution == 'Multinomial':
            self.latent_size = latent_size
            self.out_size = latent_size[0] * latent_size[1] * self.hparams['num_embeddings']
            if self.domain_vary:
                self.logits = nn.ModuleList()
                for i in range(num_domains):
                    self.logits.append(nn.Linear(num_classes, self.out_size))
            else:
                self.logits = nn.Linear(num_classes, self.out_size)

        elif self.distribution == 'Uniform':
            self.log_prob = -torch.log(torch.tensor(self.hparams['num_embeddings']).float())
        
        else:
            print(self.distribution, " distribution is not implemented.")
            
            
    def forward(self, c, d=None, n=None):
        n = torch.zeros_like(c) + n
        nnn = idx2onehot(n, n=self.N)
        c = idx2onehot(c, n=self.num_classes)
        nc = torch.cat((c, nnn), dim=-1)
        
        if self.distribution == 'Gaussian':
            if self.domain_vary:
                means = self.linear_means[d](nc)
                log_vars = self.linear_log_var[d](nc)
            else:
                means = self.linear_means(nc)
                log_vars = self.linear_log_var(nc)
            return means, log_vars
        
        elif self.distribution == 'Gaussian_fixed_variance':
            if self.domain_vary:
                means = self.linear_means[d](nc)
            else:
                means = self.linear_means(nc)
            return means, torch.zeros_like(means, device = means.device)

        elif self.distribution == 'Multinomial':
            if self.domain_vary:
                log_probs = F.log_softmax(self.logits[d](c), -1).view(
                            -1, self.latent_size[0], self.latent_size[1], self.hparams['num_embeddings'])
            else:
                log_probs = F.log_softmax(self.logits(c), -1).view(
                            -1, self.latent_size[0], self.latent_size[1], self.hparams['num_embeddings'])
            return log_probs

        elif self.distribution == 'Uniform':
            return self.log_prob

        else:
            print(self.distribution, " distribution is not implemented.")

class CVAE(Algorithm):
    """
    conditional VAE that generate x from y and z_d 
    with z_d spuriously associated with y
    and infer z_d from x
    """

    def __init__(self, input_shape, num_classes, num_domains, hparams, N):
        super(CVAE, self).__init__(input_shape, num_classes, num_domains,
                                  hparams)
        self.num_domains = num_domains
        self.N = N

        self.encoder = Encoder_New(input_shape, num_classes, num_domains, 
                        self.hparams,self.N, conditional=True, use_mlp=True)
        self.decoder = Decoder_New(input_shape, num_classes, 
                        self.hparams,self.N, conditional=True)
        self.z_prior = Cond_Prior_New(num_classes, num_domains, 
                        self.hparams, self.N, domain_vary=True, 
                        distribution = hparams['distribution'])
        self.optimizer = torch.optim.Adam(
            self.parameters(),
            lr=self.hparams["lr"],
            weight_decay=self.hparams['weight_decay']
        )

        self.hparams = hparams

    def forward(self, x_n, y, d, n):
        #for n in range(self.N):
        prior_means, prior_log_var = self.z_prior(y, d, n)
        means, log_var = self.encoder(x_n, y, d, n)
        z = self.reparameterize(means, log_var)
        recon_x = self.decoder(z, y, n)

        return recon_x, means, log_var, z, prior_means, prior_log_var
    
    def update(self, minibatches, unlabeled=None, use_cf=False):
        mse = 0.0
        kld = 0.0
        matched_cf_mse = 0.0
        num_envs = len(minibatches)

        for d, data in enumerate(minibatches):
            for n in range(self.N):
                if use_cf:
                    x,y,cf_x,cf_y = data[:,n,:,:]
                else:
                    x,y = data
                    x_n = x[:,n,:,:]
                    y_n = y
                batch_size = x_n.size(0)
                recon_x, means, log_var, z, prior_means, prior_log_var = self.forward(x_n, y_n, d, n)

                # use Gaussian noise N(0, 1)
                mse += 0.5 * F.mse_loss(recon_x.view(batch_size, -1), 
                        x_n.view(batch_size, -1), reduction='sum') / (self.N*num_envs*batch_size)
                kld += -0.5 * torch.sum(1 + log_var - prior_log_var - 
                        (log_var.exp() + (means - prior_means).pow(2))
                        /prior_log_var.exp()) / (self.N*num_envs*batch_size)

        
        loss = mse + matched_cf_mse + self.hparams['kl_weight'] * kld

        self.optimizer.zero_grad()
        loss.backward()    
        self.optimizer.step()

        if matched_cf_mse > 0:
            return {'loss': loss.item(), 'mse': mse.item(), 'kld': kld.item(), 
                    'cf_mse': matched_cf_mse.item()}
        else:
            return {'loss': loss.item(), 'mse': mse.item(), 'kld': kld.item(), 
                    'cf_mse': matched_cf_mse}
        
    def get_z(self, x_n, y, d, n):
        means, log_var = self.encoder(x_n, y, d, n)
        return means

    def inference(self, z, y, n):

        recon_x = self.decoder(z, y, n)

        return {'recon_x': recon_x}

    def reconstruct(self, x_n, y, d, n):

        means, log_var = self.encoder(x_n, y, d, n)
        recon_x = self.decoder(means, y, n)

        return recon_x
    
    def get_match_var(self, x, y, d, n):
        return self.get_z(x, y, d, n)

    def normal_log_pdf(self, mean, log_var, z):
        log_prob = -0.5*log_var - 0.5*((z-mean)/torch.sqrt(torch.exp(log_var)))**2
        return torch.sum(log_prob, dim=-1)
    
    def propensity_score(self, x_raw, d, p_y=None, weights = None):
        weights = self.hparams['weights']
        weights = torch.tensor(weights, device=x_raw.device)

        if weights is None:
            weights = torch.ones(self.N, device=x_raw.device) / self.N
        else:
            weights = weights / torch.sum(weights) 

        p_y_z_all = []
        
        for n in range(self.N):  
            x = x_raw[:,n,:,:]
            log_p_z_y = []
            for i in range(self.num_classes):
                y = torch.tensor([i]*len(x), dtype=torch.int64, device=x.device)
                z = self.get_z(x, y, d, n)
                prior_means, prior_log_var = self.z_prior(y, d, n)
                log_p_z_y.append(self.normal_log_pdf(prior_means, prior_log_var, z))
            log_p_z_y = torch.stack(log_p_z_y, dim=1)

            p_y_z = []
            for i in range(self.num_classes):
                diff = torch.exp(log_p_z_y - log_p_z_y[:,i].unsqueeze(1)) # to avoid overflow
                if p_y is not None:
                    diff = diff * (p_y/p_y[i]).unsqueeze(0)
                p_y_z.append(1/torch.sum(diff, dim=1))
            p_y_z = torch.stack(p_y_z, dim=1)
            p_y_z[p_y_z < 1e-30] = 1e-30 # avoid zeros

            p_y_z_all.append(p_y_z)
        
        p_y_z_all = torch.stack(p_y_z_all, dim=0)

        weighted_p_y_z = torch.sum(p_y_z_all * weights.unsqueeze(-1).unsqueeze(-1), dim=0)
        weighted_p_y_z = weighted_p_y_z / weighted_p_y_z.sum(dim=1, keepdim=True)
            
        return weighted_p_y_z