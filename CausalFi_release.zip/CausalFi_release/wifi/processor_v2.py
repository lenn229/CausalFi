
import os, json, time, random, collections
import numpy as np
import torch

from torch.utils.data import DataLoader
from domainbed import datasets
from domainbed.lib.fast_data_loader import InfiniteDataLoader, FastDataLoader
from domainbed.lib import misc

from domainbed.match.utils import IndexWrapper
from Time_CVAE_newpara import CVAE as Time_CVAE

from wifi.matching import wrap_datasets_new, get_final_b
from wifi.models import WiFi_ERM_New
from wifi.checkpoint import save_checkpoint

# external helpers
from algo_match import index2score

class Processor:
    def __init__(self, args, hparams, hparams2=None, device='cuda:3'):
        self.args = args
        self.hparams = hparams
        self.hparams2 = hparams2 if hparams2 is not None else {}
        self.device = device
        self.dataset = None
        self.in_splits = []
        self.out_splits = []
        self.uda_splits = []
        self.train_only_in_split = []
        self.train_only_out_split = []
        self.eval_loaders = []
        self.eval_loader_names = []
        self.eval_weights = []

    def load_data(self):
        label_env_relationship_array_train = np.zeros((5, 6, 5, 6), dtype=bool)
        for j in range(5):
            for i in range(6):
                label_env_relationship_array_train[j, i, j, i] = True
        Po = 0.9
        label_env_relationship_array_test = np.zeros((6, 5, 6), dtype=bool)
        for i in range(6):
            label_env_relationship_array_test[i, :, i] = True
        Poi = 0.1

        random.seed(self.args.seed)
        np.random.seed(self.args.seed)
        torch.manual_seed(self.args.seed)

        if self.args.dataset in vars(datasets) and self.args.dataset == "WiFi_simple_try":
            self.dataset = vars(datasets)[self.args.dataset]()
        
        elif self.args.dataset in vars(datasets) and self.args.dataset != "WiFi_simple_try":
            self.dataset = vars(datasets)[self.args.dataset](
                self.args.data_dir, self.args.test_envs, self.hparams,
                label_env_relationship_array_train, Po, label_env_relationship_array_test, Poi, 0)        
        else:
            raise NotImplementedError(f"Unknown dataset {self.args.dataset}")

        self.in_splits = []
        self.out_splits = []
        self.uda_splits = []
        for env_i, env in enumerate(self.dataset): 
            uda = []

            out, in_ = misc.split_dataset(env,
                int(len(env)*self.args.holdout_fraction),
                misc.seed_hash(self.args.trial_seed, env_i))

            if env_i in self.args.test_envs:#[0],[1],[2],[3]
                uda, in_ = misc.split_dataset(in_,
                    int(len(in_)*self.args.uda_holdout_fraction),
                    misc.seed_hash(self.args.trial_seed, env_i))

            if self.hparams['class_balanced']:
                in_weights = misc.make_weights_for_balanced_classes(in_)
                out_weights = misc.make_weights_for_balanced_classes(out)
                if uda is not None:
                    uda_weights = misc.make_weights_for_balanced_classes(uda)
            else:
                in_weights, out_weights, uda_weights = None, None, None
            self.in_splits.append((in_, in_weights))
            if len(out):
                self.out_splits.append((out, out_weights))
            if len(uda):
                self.uda_splits.append((uda, uda_weights))

        if self.args.task == "domain_adaptation" and len(self.uda_splits) == 0:
            raise ValueError("Not enough unlabeled samples for domain adaptation.")

        self.train_only_in_split = [(env, env_weights) for i, (env, env_weights) in enumerate(self.in_splits)
                                if i not in self.args.test_envs]
        
        self.train_only_out_split = [(env, env_weights) for i, (env, env_weights) in enumerate(self.out_splits)
                                if i not in self.args.test_envs]


        self.train_loaders = [InfiniteDataLoader(
            dataset=IndexWrapper(env,use_raw_index=False),
            weights=env_weights,
            batch_size=self.hparams.get('batch_size', 32),
            num_workers=self.dataset.N_WORKERS)
            for (env, env_weights) in self.train_only_in_split]


        self.uda_loaders = [InfiniteDataLoader(
            dataset=env,
            weights=env_weights,
            batch_size=self.hparams.get('batch_size', 32),
            num_workers=self.dataset.N_WORKERS)
            for i, (env, env_weights) in enumerate(self.uda_splits)
            if i in self.args.test_envs]

        self.eval_loaders = [FastDataLoader(
            dataset=env,
            batch_size=self.hparams.get('batch_size', 32),
            num_workers=self.dataset.N_WORKERS)
            for env, _ in (self.in_splits + self.out_splits + self.uda_splits)]
        
        self.eval_weights = [None for _, weights in (self.in_splits + self.out_splits + self.uda_splits)]
        self.eval_loader_names = ['env{}_in'.format(i)
            for i in range(len(self.in_splits))]
        self.eval_loader_names += ['env{}_out'.format(i)
            for i in range(len(self.out_splits))]
        self.eval_loader_names += ['env{}_uda'.format(i)
            for i in range(len(self.uda_splits))]



    def build_train_loaders(self, batch_size):
        return [InfiniteDataLoader(dataset=IndexWrapper(env, use_raw_index=False),
                                   weights=env_weights,
                                   batch_size=batch_size,
                                   num_workers=self.dataset.N_WORKERS)
                for (env, env_weights) in self.train_only_in_split]

    def load_cvae_from_checkpoint(self, ckpt_path, device='cuda:3'):
        ckpt = torch.load(ckpt_path, map_location='cpu')
        algo = Time_CVAE(self.dataset.input_shape, self.dataset.num_classes,
                         len(self.dataset) - len(self.args.test_envs), self.hparams, N=8)
        algo.load_state_dict(ckpt['model_dict'])
        algo.to(device)
        return algo

    def compute_causal_scores(self, matcher, batch_size):
        all_vars, all_ids = wrap_datasets_new(self.train_only_in_split, matcher, 
                            self.dataset.num_classes, batch_size=batch_size, 
                            dist_func=self.hparams.get('distance_func', 'kld'),
                            device=self.device, use_raw_index=False, threshold=False,
                            topk=self.hparams.get('topk', 1))
        final_b = get_final_b(all_ids)
        return all_vars, final_b

    def train_classifier(self, all_vars, final_b):
        from domainbed.lib import misc
        import numpy as np
        import json

        train_loaders = self.build_train_loaders(batch_size=self.hparams2.get('batch_size', 15))
        train_minibatches_iterator = zip(*train_loaders)
        eval_loaders = self.eval_loaders
        eval_loader_names = self.eval_loader_names
        eval_weights = self.eval_weights

        X_all, Y_all, Score_all = [], [], []
        for env_i,(env,weight) in enumerate(self.train_only_in_split):
            X_all_list, Y_all_list, Index_temp_list = [], [], []
            loader = DataLoader(IndexWrapper(env, use_raw_index=False), batch_size=1)
            for index,x,y in loader:
                X_all_list.append(x.cpu())
                Y_all_list.append(y.cpu())
                Index_temp_list.append(index.item())
            X_all.append(X_all_list)
            Y_all.append(Y_all_list)
            Score_all.append(index2score(all_vars, final_b, Index_temp_list, env_i))

        device2 = self.device
        algo = WiFi_ERM_New(self.train_only_in_split, X_all, Y_all, Score_all, device2,
                            self.dataset.input_shape, self.dataset.num_classes,
                            len(self.dataset)-len(self.args.test_envs), self.hparams, all_vars, final_b, self.hparams2)
        algo.to(device2)

        steps = self.hparams2.get('steps', 3000)
        checkpoint_freq = self.args.checkpoint_freq
        last_results_keys = None
        checkpoint_vals = collections.defaultdict(lambda: [])
        steps_per_epoch = max(1, min([len(env)/self.hparams2.get('batch_size', 15) for env,_ in self.in_splits]))

        for step in range(steps):
            minibatches = [(index, x, y) for index, x, y in next(train_minibatches_iterator)]
            algo.activate()
            step_vals = algo.update(minibatches, None)
            algo.deactivate()
            for k, v in step_vals.items():
                checkpoint_vals[k].append(v)

            if (step % checkpoint_freq == 0) or (step == steps - 1):
                results = {
                    'step': step,
                    'epoch': step / steps_per_epoch,
                    **{key: float(np.mean(val)) for key, val in checkpoint_vals.items()}
                }
                evals = zip(eval_loader_names, eval_loaders, eval_weights)
                for name, loader, weights in evals:
                    acc = misc.accuracy(algo, loader, weights, device2)
                    results[name+'_acc'] = acc
                results['mem_gb'] = torch.cuda.max_memory_allocated() / (1024.*1024.*1024.)

                results_keys = sorted(results.keys())
                if results_keys != last_results_keys:
                    misc.print_row(results_keys, colwidth=12)
                    last_results_keys = results_keys
                misc.print_row([results[key] for key in results_keys], colwidth=12)

                os.makedirs(self.args.output_dir, exist_ok=True)
                with open(os.path.join(self.args.output_dir, 'results.jsonl'), 'a') as f:
                    f.write(json.dumps({**results, 'hparams': self.hparams2, 'args': vars(self.args)}, sort_keys=True) + "\n")

                if getattr(self.args, 'save_model_every_checkpoint', False):
                    save_checkpoint(f'model_step{step}.pkl', self.dataset, algo, self.args, self.hparams2)

        save_checkpoint('model.pkl', self.dataset, algo, self.args, self.hparams2)
        with open(os.path.join(self.args.output_dir, 'done'), 'w') as f:
            f.write('done')

    def train_cvae(self):
        train_loaders = self.build_train_loaders(batch_size=self.hparams.get('batch_size', 32))
        train_minibatches_iterator = zip(*train_loaders)
        algo = Time_CVAE(self.dataset.input_shape, self.dataset.num_classes,
                         len(self.dataset) - len(self.args.test_envs), self.hparams, N=8).to(self.device)
        steps = self.hparams.get('steps', 5000); checkpoint_freq = self.args.checkpoint_freq
        last_keys=None; checkpoint_vals=collections.defaultdict(lambda: [])
        steps_per_epoch = max(1, min([len(env)/self.hparams.get('batch_size', 32) for env,_ in self.in_splits]))

        for step in range(steps):
            # convert (idx,x,y) -> (x,y) for CVAE
            minibatches = [(x.to(self.device), y.to(self.device)) for (index, x, y) in next(train_minibatches_iterator)]
            step_vals = algo.update(minibatches, None) if hasattr(algo, 'update') else {'loss': 0.0}
            keep = {'loss','mse','kld'}  # 决定要保留哪些
            for k, v in step_vals.items():
                if k in keep:
                    checkpoint_vals[k].append(v)
            #for k,v in step_vals.items(): checkpoint_vals[k].append(v)
            if (step % checkpoint_freq == 0) or (step == steps-1):
                results = {
                    'step': step,
                    'epoch': step / steps_per_epoch,
                    **{k: float(np.mean(v)) for k, v in checkpoint_vals.items()}
                }

                results_keys = sorted(results.keys())
                if results_keys != last_keys:
                    misc.print_row(results_keys, colwidth=12)
                    last_keys = results_keys
                misc.print_row([results[k] for k in results_keys], colwidth=12)

                os.makedirs(self.args.output_dir, exist_ok=True)
                with open(os.path.join(self.args.output_dir, 'results.jsonl'), 'a') as f:
                    f.write(json.dumps({**results, 'hparams': self.hparams, 'args': vars(self.args)}, sort_keys=True) + "\n")

                save_checkpoint(f'model_step{step}.pkl', self.dataset, algo, self.args, self.hparams)

                checkpoint_vals = collections.defaultdict(lambda: [])
        save_checkpoint('model.pkl', self.dataset, algo, self.args, self.hparams)
        with open(os.path.join(self.args.output_dir, 'done'), 'w') as f: f.write('done')


    def prepare_cvae(self, matcher_checkpoint, cache_output_dir=None):
        os.makedirs(cache_output_dir or self.args.output_dir, exist_ok=True)
        matcher = self.load_cvae_from_checkpoint(matcher_checkpoint, device=self.device)
        all_vars, all_ids = wrap_datasets_new(self.train_only_in_split, matcher,
                            self.dataset.num_classes, batch_size=self.hparams.get('batch_size', 32),
                            dist_func=self.hparams.get('distance_func','kld'),
                            device=self.device, use_raw_index=False, threshold=False,
                            topk=self.hparams.get('topk',1))
        final_b = get_final_b(all_ids)
        all_vars_balanced, all_ids_balanced = ([], [])
        final_b_balanced = []
        if len(self.train_only_out_split) > 0:
            all_vars_balanced, all_ids_balanced = wrap_datasets_new(self.train_only_out_split, matcher,
                            self.dataset.num_classes, batch_size=self.hparams.get('batch_size', 32),
                            dist_func=self.hparams.get('distance_func','kld'),
                            device=self.device, use_raw_index=False, threshold=False,
                            topk=self.hparams.get('topk',1))
            final_b_balanced = get_final_b(all_ids_balanced)
        cache = {"all_vars": all_vars, "all_ids": all_ids, "final_b": final_b,
                 "all_vars_balanced": all_vars_balanced, "all_ids_balanced": all_ids_balanced, "final_b_balanced": final_b_balanced}
        cache_path = os.path.join(cache_output_dir or self.args.output_dir, "matcher_cache.pkl")
        torch.save(cache, cache_path); return cache_path
