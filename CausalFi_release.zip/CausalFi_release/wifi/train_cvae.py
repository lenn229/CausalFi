
import numpy as np, torch
from wifi.args import parse_train_cvae_args, parse_hparams_json
from processor_v2 import Processor

def main():
    args = parse_train_cvae_args()
    hparams = {}
    hparams.update(parse_hparams_json(args.hparams_json))
    torch.manual_seed(args.seed); np.random.seed(args.seed)
    proc = Processor(args, hparams, device='cuda:0' if args.use_gpu else 'cpu')
    proc.load_data()
    proc.train_cvae()

if __name__ == "__main__":
    main()
