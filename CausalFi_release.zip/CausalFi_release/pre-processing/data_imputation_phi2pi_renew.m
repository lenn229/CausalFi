function [csi_recov] = data_imputation_phi2pi_renew(csi_1,temp)
%imputation function


csi_recov = zeros(800,234,4,4);
j = 1;
for i = 1:size(temp)
    if temp(i)>0.011 && temp(i)<0.02
        y1 = csi_1(i,:,:,:);
        y2 = csi_1(i+1,:,:,:);
        x_missing = j+1;
        x1 = j;
        x2 = j+2;
        y_missing1_ab = ((x2 - x_missing) * abs(y1) + (x_missing - x1) * abs(y2)) / (x2 - x1);
        
        % phase unwrap
        ph1 = angle(y1); ph2 = angle(y2);
        d = ph2 - ph1;
        ph2(d > pi) = ph2(d > pi) - 2*pi;
        ph2(d < -pi) = ph2(d < -pi) + 2*pi;
        y_missing1_ph = ((x2 - x_missing) * ph1 + (x_missing - x1) * ph2) / (x2 - x1);
        % phase wrap
        y_missing1_ph = mod(y_missing1_ph + pi, 2*pi) - pi;

        y_missing1 = y_missing1_ab.*exp(1j*y_missing1_ph);
        csi_recov(j,:,:,:) = csi_1(i,:,:,:);
        csi_recov(x_missing,:,:,:) = y_missing1;
        j = j+2;
    end
    
    if temp(i)<0.011
        x_missing = j;
        y_missing1 = csi_1(i,:,:,:);
        csi_recov(x_missing,:,:,:) = y_missing1;
        j = j+1;
    end
    
end

