%% Extract_invariant_DFS.m
%
% read and plot CSI from UDPs created using the nexmon CSI extractor (nexmon.org/csi)
% modify the configuration section to your needs
% make sure you run >mex unpack_float.c before reading values from bcm4358 or bcm4366c0 for the first time
%

clear
close all
clc
%addpath(genpath('C:\Users\64508\Desktop\pre-processing\tftb'))
%% configuration
CHIP = '4366c0';          % wifi chip (possible values 4339, 4358, 43455c0, 4366c0)
BW = 80;                % bandwidth
ss = 4;
N = 4;
packet_max = 800;
no_use_sub = [1,2,3,4,5,6,26,54,90,118,128,129,130,140,168,204,232,252,253,254,255,256];% Null subcarriers and pilot subcarriers:
samp_rate = 125;
half_rate = samp_rate / 2;

%Filter parameters
uppe_orde = 6;
uppe_stop = 50;
lowe_orde = 3;
lowe_stop = 2;
[lu,ld] = butter(uppe_orde,uppe_stop/half_rate,'low');
[hu,hd] = butter(lowe_orde,lowe_stop/half_rate,'high');
freq_bins_unwrap = [0:samp_rate/2-1 -samp_rate/2:-1]'/samp_rate;
freq_lpf_sele = freq_bins_unwrap <= uppe_stop / samp_rate & freq_bins_unwrap >= -uppe_stop / samp_rate;
freq_lpf_positive_max = sum(freq_lpf_sele(2:length(freq_lpf_sele)/2));
freq_lpf_negative_min = sum(freq_lpf_sele(length(freq_lpf_sele)/2:end));


FILE = '.\example_data\slap.pcap';

dfs_sp = zeros(8,100,800);%full data with 8 Rxs.
n_idx = 1;%one for example
[csi_store, toa_packets] = load80MHZ(FILE, BW);%loading CSI from pcap
packets = length(csi_store);
K = length(csi_store{1,1}.core{1,1}.nss{1,1}.data);
N = sum(de2bi(csi_store{1,1}.core_config));
M = sum(de2bi(csi_store{1,1}.nss_config));
csi_data_1 = zeros(packets, K, N,M);

for ii = 1:packets
    for jj = 1:N
        for kk = 1:M
            csi_data_1(ii,:,jj,kk) = csi_store{1,ii}.core{1,jj}.nss{1,kk}.data;
        end
    end
end

csi_data_1 = squeeze(csi_data_1);
csi_data_1 = csi_data_1(2:end,:,:,:);
packets = packets -1;
toa_packets = toa_packets(2:end);
csi_data = zeros(packets,234,N,ss);
    
    
% Select subcarriers     
for jj = 1:packets
    for ii = 1:N
        for Nss = 1:M
            kk = 1;
            for sub_carrier = 1:256
                if find(sub_carrier==no_use_sub)
                    continue;
                else
                    csi_data(jj,kk,ii,Nss) = csi_data_1(jj,sub_carrier,ii,Nss);
                    kk = kk + 1;
                end
            end
        end
    end
end

%data imputation
tempp = toa_packets(2:packets)-toa_packets(1:packets-1);%Inter-packet time intervals (timestamp deltas) in seconds

imputation = true;%if imputation

if imputation
    csi_data = data_imputation_phi2pi_renew(csi_data,tempp);%imputation
end

%Condition operation 
csi_data_adj = zeros(size(csi_data));%[packets,sub_carrier,N,ss]
csi_data_ref_adj = zeros(size(csi_data));
csi_data_ref_adj_temp = zeros(size(csi_data));

temp = -1;
conj_mult_pca = zeros(80,packets);
for kk = 1:4 %spatial diversity index(Nx)
    % Select Antenna Pair[WiDance]
    csi_tt = reshape(csi_data(:,:,:,kk),[size(csi_data,1) N*234]);
    csi_mean = mean(abs(csi_tt));
    csi_var = sqrt(var(abs(csi_tt)));
    csi_mean_var_ratio = csi_mean./csi_var;
    [~,iidx] = max(mean(reshape(csi_mean_var_ratio,[234 N]),1));
    csi_data_ref = repmat(csi_tt(:,(iidx-1)*234+1:iidx*234), 1, N);
    csi_data_ref = reshape(csi_data_ref,[size(csi_data_ref,1),234,N]);

    % Amp Adjust[IndoTrack] 
    alpha_sum = 0;
    for ii = 1:234 %for [1,234]
        for jj = 1:N
            amp = abs(csi_data(:,ii,jj,kk));
            alpha = min(amp(amp~=0));
            alpha_sum = alpha_sum + alpha;
            csi_data_adj(:,ii,jj,kk) = abs(abs(csi_data(:,ii,jj,kk))-alpha).*exp(1j*angle(csi_data(:,ii,jj,kk)));
        end
    end

    beta = 10*alpha_sum/(234*N);%hyperparameter

     for ii = 1:234
         for jj = 1:N
             csi_data_ref_adj(:,ii,jj,kk) = (abs(csi_data_ref(:,ii,jj))+beta).*exp(1j*angle(csi_data_ref(:,ii,jj)));
         end
     end
     
     
    for ii = 1:234 
        for jj = 1:N
            amp = abs(csi_data_ref(:,ii,jj));
            alpha = min(amp(amp~=0));
            alpha_sum = alpha_sum + alpha;
            csi_data_ref_adj_temp(:,ii,jj,kk) = abs(abs(csi_data_ref(:,ii,jj))-alpha).*exp(1j*angle(csi_data_ref(:,ii,jj)));
        end
    end


% Conj Mult
conj_mult = csi_data_adj(:,:,:,kk) .* conj(csi_data_ref_adj(:,:,:,kk));


if iidx == 1
    conj_mult = cat(3, conj_mult(:,:,2),conj_mult(:,:,3),conj_mult(:,:,4));
elseif iidx == 2
    conj_mult = cat(3, conj_mult(:,:,1),conj_mult(:,:,3),conj_mult(:,:,4));
elseif iidx == 3
    conj_mult = cat(3, conj_mult(:,:,1),conj_mult(:,:,2),conj_mult(:,:,4));
else
    conj_mult = cat(3, conj_mult(:,:,1),conj_mult(:,:,2),conj_mult(:,:,3));
end
    
%Filter Out Static Component & High Frequency Component
for ii = 1:size(conj_mult, 3)
    for kkk = 1:size(conj_mult, 2)
        conj_mult(:,kkk,ii) = filter(lu, ld, conj_mult(:,kkk,ii));
        conj_mult(:,kkk,ii) = filter(hu, hd, conj_mult(:,kkk,ii));
    end
end
    
    
% Condition on Z
for ii = 1:3% spatial diversity index(Rx)
    for pc = 1:2 % principal-component diversity index    
        conj_mult_temp = conj_mult;
        conj_mult_temp = reshape(conj_mult_temp,[],234*3);
        [pca_coef,score,latent] = pca(conj_mult_temp(:,1+(ii-1)*234:ii*234));    
        [pppp,pp_index] = max(abs(real(score')));
        conj_mult_pca_temp = conj_mult_temp(:,1+(ii-1)*234:ii*234) * pca_coef(:,pc);
        
        
        % TFA With CWT or STFT(using STFT)
        time_instance = 1:length(conj_mult_pca_temp);
        window_size = round(samp_rate/2);
        if(~mod(window_size,2))
            window_size = window_size + 1;
        end
        freq_time_prof_allfreq = tfrsp(conj_mult_pca_temp, time_instance,...
            samp_rate, tftb_window(window_size, 'gauss'));
        
        % Select Concerned Freq
        freq_time_prof = freq_time_prof_allfreq(freq_lpf_sele, :);
        
        % Spectrum Normalization By Sum For Each Snapshot
        freq_time_prof = abs(freq_time_prof) ./ repmat(sum(abs(freq_time_prof),1),size(freq_time_prof,1), 1);
         
        % Frequency Bin(Corresponding to FFT Results)
        freq_bin = [0:freq_lpf_positive_max -1*freq_lpf_negative_min:-1];

        %Score the current DFS candidate by its overall statistical characteristics
        aaa = sum(sqrt(var(abs(freq_time_prof))));
        if temp < aaa
            temp = aaa;
            conj_mult_pca = freq_time_prof;
        end
    end
end

end
% Cyclic Doppler Spectrum According To frequency bin
[~,idx] = max(freq_bin);
circ_len = length(freq_bin) - idx;
freq_time_prof = circshift(conj_mult_pca, [circ_len 0]);


 figure;
 colormap(jet);
 mesh(1:size(freq_time_prof,2),-49:50,squeeze(freq_time_prof(:,:)));view([0,90]);
 xlim([0,size(freq_time_prof,2)]);ylim([-49,50]);
 set(gcf,'WindowStyle','normal','Position', [300,300,400,250]); % window size
 set (gca,'color','none', 'fontsize', 12); % fontsize
 xlabel('Packets'); 
 ylabel('Frequency Shift (Hz)');

 colorbar; %Use colorbar only if necessary
 caxis([min(freq_time_prof(:)),max(freq_time_prof(:))]);
     
dfs_sp(n_idx,:,1:size(freq_time_prof,2)) =  freq_time_prof;


